import * as THREE from 'three';
import { COLORS, SIZES, GAME } from '../utils/constants.js';
import { Bullet, OptimizedBullet, BossBullet, ShaderBossBullet } from './projectiles.js';
import { createShaderExplosion } from '../utils/shaders.js';

// Create a new class for instanced enemy rendering
export class InstancedEnemyRenderer {
    constructor(scene) {
        this.scene = scene;
        
        // Initialize geometries and materials
        this.geometries = {
            body: new THREE.BoxGeometry(0.5, 1, 0.5), // Standard enemy body
            gun: new THREE.BoxGeometry(
                SIZES.GUN.WIDTH * 0.8,  // Width
                SIZES.GUN.WIDTH,        // Height (square profile)
                SIZES.GUN.DEPTH * 2.5   // Length
            ),
            bossEmblem: new THREE.SphereGeometry(0.4, 8, 8) // Boss emblem
        };
        
        this.materials = {
            regular: new THREE.MeshBasicMaterial({ color: COLORS.ENEMY.REGULAR }),
            chubby: new THREE.MeshBasicMaterial({ color: COLORS.ENEMY.CHUBBY }),
            thin: new THREE.MeshBasicMaterial({ color: COLORS.ENEMY.THIN }),
            boss: new THREE.MeshBasicMaterial({ color: COLORS.ENEMY.BOSS }),
            bossEmblem: new THREE.MeshBasicMaterial({ 
                color: COLORS.ENEMY.BOSS, 
                transparent: true, 
                opacity: 0.3,
                blending: THREE.AdditiveBlending 
            }),
            gun: new THREE.MeshBasicMaterial({ color: COLORS.GUN })
        };
        
        // Set up instanced meshes for each enemy type (start with reasonable pool sizes)
        const INITIAL_POOL_SIZE = 50; // Adjust based on expected max enemies
        const BOSS_POOL_SIZE = 2; // Only need a few bosses
        
        this.instancedMeshes = {
            regular: {
                body: new THREE.InstancedMesh(this.geometries.body, this.materials.regular, INITIAL_POOL_SIZE),
                gun: new THREE.InstancedMesh(this.geometries.gun, this.materials.gun, INITIAL_POOL_SIZE)
            },
            chubby: {
                body: new THREE.InstancedMesh(this.geometries.body, this.materials.chubby, INITIAL_POOL_SIZE),
                gun: new THREE.InstancedMesh(this.geometries.gun, this.materials.gun, INITIAL_POOL_SIZE)
            },
            thin: {
                body: new THREE.InstancedMesh(this.geometries.body, this.materials.thin, INITIAL_POOL_SIZE),
                gun: new THREE.InstancedMesh(this.geometries.gun, this.materials.gun, INITIAL_POOL_SIZE)
            },
            boss: {
                body: new THREE.InstancedMesh(this.geometries.body, this.materials.boss, BOSS_POOL_SIZE),
                gun: new THREE.InstancedMesh(this.geometries.gun, this.materials.gun, BOSS_POOL_SIZE),
                emblem: new THREE.InstancedMesh(this.geometries.bossEmblem, this.materials.bossEmblem, BOSS_POOL_SIZE)
            }
        };
        
        // Set initial visibility to false for all instances
        ['regular', 'chubby', 'thin', 'boss'].forEach(type => {
            const count = type === 'boss' ? BOSS_POOL_SIZE : INITIAL_POOL_SIZE;
            for (let i = 0; i < count; i++) {
                this.instancedMeshes[type].body.setMatrixAt(i, new THREE.Matrix4().makeScale(0, 0, 0));
                this.instancedMeshes[type].gun.setMatrixAt(i, new THREE.Matrix4().makeScale(0, 0, 0));
                if (type === 'boss') {
                    this.instancedMeshes[type].emblem.setMatrixAt(i, new THREE.Matrix4().makeScale(0, 0, 0));
                }
            }
            
            this.instancedMeshes[type].body.instanceMatrix.needsUpdate = true;
            this.instancedMeshes[type].gun.instanceMatrix.needsUpdate = true;
            if (type === 'boss') {
                this.instancedMeshes[type].emblem.instanceMatrix.needsUpdate = true;
            }
            
            // Add meshes to scene
            this.scene.add(this.instancedMeshes[type].body);
            this.scene.add(this.instancedMeshes[type].gun);
            if (type === 'boss') {
                this.scene.add(this.instancedMeshes[type].emblem);
            }
        });
        
        // Keep track of used indices for each type
        this.usedIndices = {
            regular: new Set(),
            chubby: new Set(),
            thin: new Set(),
            boss: new Set()
        };
        
        // Matrices for calculations
        this.tempMatrix = new THREE.Matrix4();
        this.tempMatrixGun = new THREE.Matrix4();
        this.tempMatrixEmblem = new THREE.Matrix4();
        this.tempPosition = new THREE.Vector3();
        this.tempQuaternion = new THREE.Quaternion();
        this.tempScale = new THREE.Vector3();
        
        // Track lights for boss enemies
        this.bossLights = {};
    }
    
    // Get enemy type key for internal use
    getTypeKey(type) {
        switch(type) {
            case 'CHUBBY': return 'chubby';
            case 'THIN': return 'thin';
            case 'BOSS': return 'boss';
            default: return 'regular';
        }
    }
    
    // Get next available index for an enemy type
    getNextIndex(typeKey) {
        const instancedMesh = this.instancedMeshes[typeKey].body;
        const usedIndices = this.usedIndices[typeKey];
        
        // First validate the usedIndices set - remove any indices that aren't valid
        // This helps fix potential desynchronization issues
        for (const index of usedIndices) {
            if (index >= instancedMesh.count) {
                console.warn(`Removing invalid index ${index} from ${typeKey} tracking`);
                usedIndices.delete(index);
            }
        }
        
        // Try to find an unused index
        for (let i = 0; i < instancedMesh.count; i++) {
            if (!usedIndices.has(i)) {
                usedIndices.add(i);
                return i;
            }
        }
        
        // If we get here, all indices are used - need to expand
        this.expandPool(typeKey);
        const newIndex = instancedMesh.count - 1;
        usedIndices.add(newIndex);
        return newIndex;
    }
    
    // Expand the instance pool for a given type
    expandPool(typeKey) {
        const oldCount = this.instancedMeshes[typeKey].body.count;
        const newCount = oldCount * 2; // Double the size
        
        console.log(`Expanding ${typeKey} enemy pool from ${oldCount} to ${newCount}`);
        
        // Create new instanced meshes with larger size
        const newBodyMesh = new THREE.InstancedMesh(
            this.geometries.body,
            this.materials[typeKey],
            newCount
        );
        
        const newGunMesh = new THREE.InstancedMesh(
            this.geometries.gun,
            this.materials.gun,
            newCount
        );
        
        // Copy existing matrices
        for (let i = 0; i < oldCount; i++) {
            this.instancedMeshes[typeKey].body.getMatrixAt(i, this.tempMatrix);
            newBodyMesh.setMatrixAt(i, this.tempMatrix);
            
            this.instancedMeshes[typeKey].gun.getMatrixAt(i, this.tempMatrix);
            newGunMesh.setMatrixAt(i, this.tempMatrix);
        }
        
        // Initialize new slots as invisible
        for (let i = oldCount; i < newCount; i++) {
            newBodyMesh.setMatrixAt(i, new THREE.Matrix4().makeScale(0, 0, 0));
            newGunMesh.setMatrixAt(i, new THREE.Matrix4().makeScale(0, 0, 0));
        }
        
        // Update matrices
        newBodyMesh.instanceMatrix.needsUpdate = true;
        newGunMesh.instanceMatrix.needsUpdate = true;
        
        // Remove old meshes from scene
        this.scene.remove(this.instancedMeshes[typeKey].body);
        this.scene.remove(this.instancedMeshes[typeKey].gun);
        
        // Replace with new meshes
        this.instancedMeshes[typeKey].body = newBodyMesh;
        this.instancedMeshes[typeKey].gun = newGunMesh;
        
        // Add new meshes to scene
        this.scene.add(newBodyMesh);
        this.scene.add(newGunMesh);
    }
    
    // Update an enemy's visual representation
    updateEnemy(enemy) {
        try {
            if (!enemy.isActive) return;
            
            const typeKey = this.getTypeKey(enemy.type);
            const index = enemy.instanceIndex;
            
            if (index === undefined || !this.usedIndices[typeKey].has(index)) {
                // Removed console.error - no need to log every instance
                
                // Attempt to recover by requesting a new index
                if (enemy.isActive && !enemy.isDying && !enemy.isBlownAway) {
                    // Removed console.log - too frequent
                    
                    // Get a new valid index
                    const newIndex = this.getNextIndex(typeKey);
                    enemy.instanceIndex = newIndex;
                    
                    // Now continue with update using the new index
                } else {
                    // Can't recover non-active or dying/blown away enemies
                    return;
                }
            }
            
            // Check if index is within bounds for both meshes
            if (index >= this.instancedMeshes[typeKey].body.count ||
                index >= this.instancedMeshes[typeKey].gun.count) {
                // Only log this rarely with a throttle
                if (Math.random() < 0.05) { // Only log 5% of cases
                    console.warn(`Enemy index out of bounds`);
                }
                return;
            }
            
            // Special case handling for death animation and blown away states
            if (enemy.isDying || enemy.isBlownAway) {
                // Hide the enemy during death/blown away animations
                this.hideInstance(enemy);
                return;
            }
            
            // Get body scale based on enemy type
            const bodyScale = new THREE.Vector3(1, 1, 1);
            
            // Define base height BEFORE the switch statement
            // Base height is the vertical position of the enemy above the ground
            let baseHeight = 0.5; // Default base height above floor
            
            switch(enemy.type) {
                case 'BOSS':
                    bodyScale.set(3, 3, 3);
                    // Make the boss base position higher to avoid clipping with floor splats
                    baseHeight = 1.5; // Increased height for boss
                    break;
                case 'CHUBBY':
                    bodyScale.set(1.5, 0.8, 1.5);
                    break;
                case 'THIN':
                    bodyScale.set(0.6, 1.6, 0.6);
                    break;
                default: // REGULAR
                    // Slightly random variations for regular enemies
                    const xzScale = enemy.randomScale.x; // Using stored random scale
                    const yScale = enemy.randomScale.y;  
                    bodyScale.set(xzScale, yScale, xzScale);
            }
            
            // Jump animation - Apply bounce effect
            let position = enemy.position.clone();
            
            if (enemy.jumpTime !== undefined) {
                // Calculate step cycle - faster animation for more natural walking
                const stepCycle = Math.sin(enemy.jumpTime * 15);
                
                // Calculate movement intensity based on velocity
                const speed = enemy.velocity.length();
                const movementIntensity = Math.min(1.0, speed * 12); // Adjusted for better visibility
                
                // Apply jump height with more subtle bounce
                const baseJumpHeight = 0.4; // Reduced for subtler effect
                const jumpHeight = Math.abs(stepCycle) * baseJumpHeight * movementIntensity;
                
                // Apply squash and stretch - more subtle deformation
                const baseSquashFactor = 0.4; // Reduced for subtler squash
                const squashFactor = baseSquashFactor * movementIntensity;
                
                // Modify scale based on animation
                if (speed > 0.1) { // Only apply deformation if actually moving
                    bodyScale.y *= (1 - jumpHeight * squashFactor);
                    bodyScale.x *= (1 + jumpHeight * squashFactor * 0.5);
                    bodyScale.z *= (1 + jumpHeight * squashFactor * 0.5);
                }
                
                // Calculate position with jump height
                position.y = baseHeight + jumpHeight;
            } else {
                position.y = baseHeight;
            }
            
            // Body matrix update
            this.tempMatrix.compose(
                position,
                enemy.quaternion,
                bodyScale
            );
            
            this.instancedMeshes[typeKey].body.setMatrixAt(index, this.tempMatrix);
            
            // Gun position and rotation
            // Calculate the gun's world position based on enemy's position and orientation
            // Adjusted gun height for consistent placement
            const gunPosition = new THREE.Vector3(0, 0.1, SIZES.PLAYER / 2 + (SIZES.GUN.DEPTH * 2.5) / 2);
            gunPosition.applyQuaternion(enemy.quaternion);
            gunPosition.add(position);
            
            // Gun matrix update - gun always shares the enemy's rotation
            this.tempMatrixGun.compose(
                gunPosition,
                enemy.quaternion,
                new THREE.Vector3(1, 1, 1) // No scale modification for gun
            );
            
            this.instancedMeshes[typeKey].gun.setMatrixAt(index, this.tempMatrixGun);
            
            // Special handling for Boss emblem
            if (typeKey === 'boss') {
                // Update the boss emblem
                const emblemPosition = position.clone();
                emblemPosition.y += 2.5; // Position higher above boss's head - adjusted to new height
                
                // Calculate pulse animation for emblem
                const pulseScale = 1 + Math.sin(enemy.jumpTime * 3) * 0.2;
                const emblemScale = new THREE.Vector3(pulseScale, pulseScale, pulseScale);
                
                this.tempMatrixEmblem.compose(
                    emblemPosition,
                    enemy.quaternion,
                    emblemScale
                );
                
                this.instancedMeshes[typeKey].emblem.setMatrixAt(index, this.tempMatrixEmblem);
                
                // Update boss light if present
                if (!this.bossLights[index]) {
                    // Create a boss light if it doesn't exist
                    const light = new THREE.PointLight(COLORS.ENEMY.BOSS, 0.8, 3);
                    this.scene.add(light);
                    this.bossLights[index] = light;
                }
                
                // Update light position and intensity
                const light = this.bossLights[index];
                light.position.copy(emblemPosition);
                light.intensity = 0.5 + Math.sin(enemy.jumpTime * 3) * 0.3;
            }
        } catch (error) {
            console.error("Error in updateEnemy:", error, "for enemy:", enemy);
        }
    }
    
    // Helper method to hide an instance
    hideInstance(enemy) {
        try {
            const typeKey = this.getTypeKey(enemy.type);
            const index = enemy.instanceIndex;
            
            if (index === undefined || !this.usedIndices[typeKey].has(index)) {
                // Just return without error - the instance is already gone or invalid
                return;
            }
            
            // Make sure index is within bounds
            if (index >= this.instancedMeshes[typeKey].body.count) {
                console.warn(`Cannot hide instance with out-of-bounds index: ${index} for type: ${typeKey}`);
                return;
            }
            
            // Set matrices to zero scale (invisible)
            const zeroMatrix = new THREE.Matrix4().makeScale(0, 0, 0);
            this.instancedMeshes[typeKey].body.setMatrixAt(index, zeroMatrix);
            this.instancedMeshes[typeKey].gun.setMatrixAt(index, zeroMatrix);
            
            if (typeKey === 'boss' && this.instancedMeshes[typeKey].emblem) {
                this.instancedMeshes[typeKey].emblem.setMatrixAt(index, zeroMatrix);
                
                // Hide boss light if present
                if (this.bossLights[index]) {
                    this.bossLights[index].intensity = 0;
                }
            }
            
            // NOTE: Not updating instance matrices here
            // This will be done in the batch update at the end of the frame
        } catch (error) {
            console.error("Error in hideInstance:", error, "for enemy:", enemy);
        }
    }
    
    // Release an instance when an enemy is deactivated
    releaseInstance(enemy) {
        if (enemy.instanceIndex === undefined) return;
        
        const typeKey = this.getTypeKey(enemy.type);
        const index = enemy.instanceIndex;
        
        if (!this.usedIndices[typeKey].has(index)) {
            // Removed warning log - too frequent
            // Still clear the enemy's reference to avoid future errors
            enemy.instanceIndex = undefined;
            return;
        }
        
        // Hide the instance completely
        this.hideInstance(enemy);
        
        // Clean up boss light if present
        if (typeKey === 'boss' && this.bossLights[index]) {
            this.scene.remove(this.bossLights[index]);
            delete this.bossLights[index];
        }
        
        // Release the index
        this.usedIndices[typeKey].delete(index);
        
        // Remove the reference from the enemy - ensure complete deletion
        enemy.instanceIndex = undefined;
    }
    
    // Cleanup resources
    cleanup() {
        ['regular', 'chubby', 'thin', 'boss'].forEach(type => {
            this.scene.remove(this.instancedMeshes[type].body);
            this.scene.remove(this.instancedMeshes[type].gun);
            
            if (type === 'boss' && this.instancedMeshes[type].emblem) {
                this.scene.remove(this.instancedMeshes[type].emblem);
            }
        });
        
        // Clean up geometries and materials
        this.geometries.body.dispose();
        this.geometries.gun.dispose();
        if (this.geometries.bossEmblem) this.geometries.bossEmblem.dispose();
        
        Object.values(this.materials).forEach(material => {
            material.dispose();
        });
        
        // Clean up boss lights
        Object.values(this.bossLights).forEach(light => {
            this.scene.remove(light);
        });
        this.bossLights = {};
    }
    
    // Add a batch update method to update all matrices at once for better performance
    batchUpdate() {
        // Only mark matrices as needing update once per frame
        ['regular', 'chubby', 'thin', 'boss'].forEach(typeKey => {
            const bodyMesh = this.instancedMeshes[typeKey].body;
            const gunMesh = this.instancedMeshes[typeKey].gun;
            
            if (bodyMesh && bodyMesh.count > 0) {
                bodyMesh.instanceMatrix.needsUpdate = true;
            }
            
            if (gunMesh && gunMesh.count > 0) {
                gunMesh.instanceMatrix.needsUpdate = true;
            }
            
            // Update boss emblem if present
            if (typeKey === 'boss' && this.instancedMeshes[typeKey].emblem) {
                this.instancedMeshes[typeKey].emblem.instanceMatrix.needsUpdate = true;
            }
        });
    }
}

export class Enemy {
    constructor(scene, position, type = 'REGULAR', spawnManager = null) {
        this.scene = scene;
        this.position = position.clone();
        this.type = type;
        this.isActive = true;
        this.velocity = new THREE.Vector3(0, 0, 0);
        this.speed = this.getSpeedByType();
        this.health = this.getHealthByType();
        this.jumpTime = Math.random() * 10; // Randomize jump animation phase
        this.spawnManager = spawnManager;
        this.attachedBullets = []; // Track attached paintballs
        this.isDying = false; // Flag for dying animation
        this.deathTime = 0; // Timer for death animation
        this.hitEffects = []; // Store hit effects for animation
        this.shaderEffects = []; // Store shader-based effects for animation
        this.audioManager = spawnManager.audioManager; // Get audio manager from spawn manager
        
        // Array to track temp lights for cleanup
        this.tempLights = [];
        // Store interval IDs for cleanup
        this.flashInterval = null;
        
        // Generate a unique ID for this enemy (for sound variety)
        this.enemyId = Math.floor(Math.random() * 1000000);
        
        // Blown away state for grenades
        this.isBlownAway = false;
        this.blownAwayVelocity = new THREE.Vector3(0, 0, 0);
        this.blownAwayRotation = new THREE.Vector3(0, 0, 0);
        this.gravity = 9.8; // Gravity for physics
        
        // Shooting properties
        this.lastShotTime = 0;
        this.shootingCooldown = this.getShootingCooldownByType();
        this.shootingRange = 15; // Units to start shooting from
        
        // Store rotation as quaternion for instanced rendering
        this.quaternion = new THREE.Quaternion();
        this.rotation = 0; // Initialize rotation angle
        
        // Store random scale factors for regular enemies
        this.randomScale = new THREE.Vector3(
            0.8 + Math.random() * 0.4, // x: 0.8 to 1.2
            0.9 + Math.random() * 0.4, // y: 0.9 to 1.3
            0.8 + Math.random() * 0.4  // z: 0.8 to 1.2 (will use x value)
        );
        
        // Spatial partitioning support - initialize position for grid
        this.gridPosition = null;
    }
    
    getHealthByType() {
        switch(this.type) {
            case 'CHUBBY': return 3;
            case 'THIN': return 1;
            case 'BOSS': return GAME.BOSS_HEALTH;
            default: return 2; // REGULAR
        }
    }
    
    getSizeByType() {
        switch(this.type) {
            case 'CHUBBY': return SIZES.ENEMIES.CHUBBY;
            case 'THIN': return SIZES.ENEMIES.THIN;
            case 'BOSS': return SIZES.ENEMIES.REGULAR * 3;
            default: return SIZES.ENEMIES.REGULAR;
        }
    }
    
    getColorByType() {
        switch(this.type) {
            case 'CHUBBY': return COLORS.ENEMY.CHUBBY;
            case 'THIN': return COLORS.ENEMY.THIN;
            case 'BOSS': return COLORS.ENEMY.BOSS;
            default: return COLORS.ENEMY.REGULAR;
        }
    }
    
    getSpeedByType() {
        switch(this.type) {
            case 'CHUBBY': 
                return GAME.SPEEDS.ENEMY.CHUBBY;
            case 'THIN': 
                return GAME.SPEEDS.ENEMY.THIN;
            case 'BOSS':
                return GAME.SPEEDS.ENEMY.REGULAR * 0.7; // Slower than regular enemies
            default: // REGULAR
                return GAME.SPEEDS.ENEMY.REGULAR;
        }
    }
    
    getShootingCooldownByType() {
        switch(this.type) {
            case 'CHUBBY': return 5000; // 5 seconds between shots
            case 'THIN': return 4000; // 4 seconds between shots
            case 'BOSS': return GAME.BOSS_SHOOTING_COOLDOWN || 2000;
            default: return 3000; // 3 seconds between shots for regular enemies
        }
    }
    
    // Add instance validation method to ensure instance is valid
    validateInstanceIndex() {
        // Only validate active enemies with instance indices
        if (!this.isActive || this.instanceIndex === undefined) return false;
        
        // Skip validation for dying or blown away enemies
        if (this.isDying || this.isBlownAway) return false;
        
        // Check if we have a renderer via spawn manager
        if (!this.spawnManager || 
            !this.spawnManager.enemyPool || 
            !this.spawnManager.enemyPool.instancedRenderer) {
            return false;
        }
        
        const renderer = this.spawnManager.enemyPool.instancedRenderer;
        const typeKey = renderer.getTypeKey(this.type);
        
        // Check if index is valid in the renderer
        const isValid = (
            this.instanceIndex !== undefined &&
            renderer.usedIndices[typeKey].has(this.instanceIndex) &&
            this.instanceIndex < renderer.instancedMeshes[typeKey].body.count
        );
        
        // If not valid, request a new index
        if (!isValid) {
            // Get a new index and update the enemy
            this.instanceIndex = renderer.getNextIndex(typeKey);
            return true; // Index has been changed
        }
        
        return false; // No changes needed
    }
    
    update(dt, playerPosition) {
        if (!this.isActive) return false;
        
        if (!playerPosition) {
            return false;
        }
        
        // Check if enemy is dying
        if (this.isDying) {
            this.updateDeathAnimation(dt);
            return true;
        }
        
        // Check if enemy is blown away by a grenade
        if (this.isBlownAway) {
            this.updateBlownAwayAnimation(dt);
            return true;
        }
        
        // Get camera for reference but disable frustum culling 
        if (this.scene && !this._camera) {
            this._camera = this.scene.getObjectByName('camera');
        }
        
        // DISABLE CULLING: Force all enemies to always update visually
        let isVisible = true;
        this._detailLevel = 'high';
        this._updateVisuals = true;
        
        // Calculate movement behavior based on player position (core gameplay logic)
        const directionToPlayer = new THREE.Vector3()
            .subVectors(playerPosition, this.position)
            .normalize();
        
        const distanceToPlayer = this.position.distanceTo(playerPosition);
        const optimalDistance = this.getOptimalShootingDistance();
        
        // Get behavior even if not visible (for gameplay consistency)
        const behavior = this.getMovementBehavior(
            directionToPlayer, 
            playerPosition,
            distanceToPlayer, 
            optimalDistance
        );
        
        // Update velocity based on behavior
        this.velocity.copy(behavior.direction);
        this.velocity.multiplyScalar(this.speed * behavior.speedMultiplier);
        
        // Apply movement using velocity
        const moveVector = this.velocity.clone().multiplyScalar(dt);
        this.position.add(moveVector);
        
        // Update rotation to face movement direction - ALWAYS update rotation regardless of visibility
        if (this.velocity.length() > 0.001) {
            const targetRotation = Math.atan2(this.velocity.x, this.velocity.z);
            
            // Smoothly interpolate rotation
            let rotationDiff = targetRotation - this.rotation;
            
            // Handle wrapping around 2PI
            if (rotationDiff > Math.PI) rotationDiff -= Math.PI * 2;
            if (rotationDiff < -Math.PI) rotationDiff += Math.PI * 2;
            
            // Smoothly rotate
            this.rotation += rotationDiff * 0.1;
            
            // Update quaternion to match rotation
            this.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.rotation);
        }
        
        // Always update jump animation time
        this.jumpTime += dt;
        
        // Always update visuals - no culling
        if (this.spawnManager && this.spawnManager.enemyPool && 
            this.spawnManager.enemyPool.instancedRenderer) {
            this.spawnManager.enemyPool.instancedRenderer.updateEnemy(this);
        }
        
        // Even if not visible, perform shooting logic only if not dying or blown away
        if (behavior.shouldShoot && this.canShoot() && !this.isDying && !this.isBlownAway) {
            if (Math.random() < 0.3) {  // Add randomness to shooting
                this.tryShoot(directionToPlayer);
            }
        }
        
        // Update damage flashing according to detail level
        if (this.damageFlashTime > 0) {
            this.damageFlashTime -= dt * 1000; 
            
            // Only update flash visuals if visible and according to LOD
            if (this._updateVisuals) {
                const flashFrequency = this._detailLevel === 'high' ? 100 : 200;
                if (Date.now() % flashFrequency < flashFrequency / 2) {
                    if (this.body && this.body.material) {
                        this.body.material.emissive.setHex(0xffffff);
                    }
                } else {
                    if (this.body && this.body.material) {
                        this.body.material.emissive.setHex(0x000000);
                    }
                }
            }
            
            // Reset flash when done
            if (this.damageFlashTime <= 0) {
                this.damageFlashTime = 0;
                if (this.body && this.body.material) {
                    this.body.material.emissive.setHex(0x000000);
                }
            }
        }
        
        // Increment frame counter for animation timing
        this.frameCounter = (this.frameCounter || 0) + 1;
        
        return true;
    }
    
    // Method to get optimal shooting distance based on enemy type
    getOptimalShootingDistance() {
        switch(this.type) {
            case 'CHUBBY':
                return 3
                ; // Chubby enemies prefer to be closer (was 8)
            case 'THIN':
                return 3; // Thin enemies prefer to stay further away (was 12)
            case 'BOSS':
                return 4; // Boss stays a bit further
            default: // REGULAR
                return 3; // Regular enemies maintain a medium distance (was 10)
        }
    }
    
    getMovementBehavior(directionToPlayer, playerPosition, distanceToPlayer, optimalDistance) {
        // Calculate movement direction based on the distance to player
        let finalDirection;
        
        // Determine if we should move towards or away from player based on distance
        if (distanceToPlayer < optimalDistance - 1) {
            // Too close - move away from player
            finalDirection = directionToPlayer.clone().negate(); // Reverse direction
        } 
        else if (distanceToPlayer > optimalDistance + 3) {
            // Too far - move towards player
            finalDirection = directionToPlayer.clone();
        }
        else {
            // In optimal shooting range - strafe around player
            // Create a perpendicular direction to circle around the player
            finalDirection = new THREE.Vector3(
                directionToPlayer.z, 
                0, 
                -directionToPlayer.x
            );
            
            // Randomly change strafe direction sometimes
            if (Math.random() < 0.01) { // 1% chance per frame to change strafe direction
                finalDirection.negate();
            }
        }
                
        // Add type-specific behaviors and randomness
        switch(this.type) {
            case 'CHUBBY':
                // Chubby enemies are more direct with minimal randomness
                finalDirection.add(new THREE.Vector3(
                    (Math.random() - 0.5) * 0.05,
                    0,
                    (Math.random() - 0.5) * 0.05
                ));
                break;
                
            case 'THIN':
                // Thin enemies are more erratic but still maintain distance
                finalDirection.add(new THREE.Vector3(
                    (Math.random() - 0.5) * 0.15,
                    0,
                    (Math.random() - 0.5) * 0.15
                ));
                
                // Thin enemies have more pronounced strafing behavior
                if (distanceToPlayer > optimalDistance - 2 && distanceToPlayer < optimalDistance + 2) {
                    // Add more strafing component
                    const strafeVector = new THREE.Vector3(
                        directionToPlayer.z, 
                        0, 
                        -directionToPlayer.x
                    );
                    finalDirection.add(strafeVector.multiplyScalar(0.5));
                }
                break;
            
            case 'BOSS':
                // Boss has more deliberate movement with slight randomness
                finalDirection.add(new THREE.Vector3(
                    (Math.random() - 0.5) * 0.08,
                    0,
                    (Math.random() - 0.5) * 0.08
                ));
                break;
                
            default: // REGULAR
                // Regular enemies have moderate randomness
                finalDirection.add(new THREE.Vector3(
                    (Math.random() - 0.5) * 0.1,
                    0,
                    (Math.random() - 0.5) * 0.1
                ));
        }
        
        // Determine if the enemy should shoot based on distance
        const shouldShoot = distanceToPlayer <= this.shootingRange && 
                          distanceToPlayer >= optimalDistance * 0.5;
        
        // Calculate a speed multiplier based on distance
        let speedMultiplier = 1.0;
        
        // Slow down slightly when at optimal distance
        if (Math.abs(distanceToPlayer - optimalDistance) < 2) {
            speedMultiplier = 0.8;
        }
        
        // Return an object with direction and speedMultiplier properties
        return {
            direction: finalDirection.normalize(),
            speedMultiplier: speedMultiplier,
            shouldShoot: shouldShoot
        };
    }
    
    attachBullet(bullet) {
        // Generate random offset on enemy's body that takes into account the enemy's shape
        const size = this.getSizeByType();
        const scaleX = this.type === 'THIN' ? 0.6 : (this.type === 'CHUBBY' ? 1.5 : (this.type === 'BOSS' ? 3 : 1));
        const scaleY = this.type === 'THIN' ? 1.6 : (this.type === 'CHUBBY' ? 0.8 : (this.type === 'BOSS' ? 3 : 1));
        const scaleZ = scaleX;
        
        // Scale the offsets by the enemy's dimensions
        const randomOffset = new THREE.Vector3(
            (Math.random() - 0.5) * size * scaleX * 0.8,  // Scale X offset by enemy width
            (Math.random() - 0.5) * size * scaleY * 0.8 + size * scaleY * 0.5,  // Scale Y offset by enemy height
            (Math.random() - 0.5) * size * scaleZ * 0.8   // Scale Z offset by enemy depth
        );
        
        // Create bullet position
        const bulletPosition = this.position.clone().add(randomOffset);
        
        // For OptimizedBullet, we don't need the bullet mesh to be visible
        // Instead we'll create a decal effect directly on the enemy
        if (bullet.constructor.name === "OptimizedBullet" && bullet.decalManager) {
            // Create a local normal (pointing away from the center of the enemy)
            const normal = randomOffset.clone().normalize();
            
            // Create the impact decal at the hit position
            bullet.createImpactDecal(bulletPosition, normal, this);
            
            // We still need to count this as an attached bullet for the enemy logic
            // even though visually it's a decal
            this.attachedBullets.push({
                isDecal: true,
                offset: randomOffset
            });
        } else {
            // Regular bullet - store the bullet and its relative position
            this.attachedBullets.push({
                bullet: bullet,
                offset: randomOffset
            });
            
            // Make bullet look like it's embedded in the enemy
            if (bullet.mesh) {
                // Add a slight random rotation for variety
                bullet.mesh.rotation.set(
                    Math.random() * Math.PI * 0.5,
                    Math.random() * Math.PI * 2,
                    Math.random() * Math.PI * 0.5
                );
                bullet.mesh.scale.set(1.5, 1.5, 1.5); // More cube-like shape
                
                // Set the bullet's position
                bullet.mesh.position.copy(bulletPosition);
            }
            
            // Notify bullet that it's attached
            bullet.attachToEnemy(this);
        }
        
        // Create impact effect
        this.createBulletImpactEffect(randomOffset);
        
        // Reduce health
        this.takeDamage(1, false); // Don't die yet, just track damage
        
        return this.attachedBullets.length;
    }
    
    createBulletImpactEffect(hitOffset) {
        // No longer create splash sphere or point light - just use the damage flash
        // This improves performance by removing expensive light and geometry operations
        
        // Instead of creating a splash effect, we'll just show the damage flash
        // which is already called in takeDamage()
    }
    
    takeDamage(amount, canDie = true) {
        if (!this.isActive || this.isDying) return;
        
        this.health -= amount;
        
        // Flash effect for damage
        if (this.spawnManager) {
            // Enhanced damage flash for better visibility
            this.showDamageFlash();
        }
        
        // Special handling for boss
        if (this.type === 'BOSS') {
            // Ensure boss can only die when health is 0 or below
            if (this.health <= 0 && canDie) {
                // Ensure all boss effects are cleaned up
                this.cleanupBossEffects();
                this.startDyingAnimation();
                
                // Notify spawn manager that boss was defeated
                if (this.spawnManager) {
                    this.spawnManager.enemyDefeated();
                }
            }
        } else if (this.health <= 0 && canDie) {
            this.startDyingAnimation();
            
            // Notify spawn manager that an enemy was defeated
            if (this.spawnManager) {
                this.spawnManager.enemyDefeated();
            }
        }
    }
    
    cleanupBossEffects() {
        // Clean up any boss-specific effects
        if (this.spawnManager?.enemyPool?.instancedRenderer?.bossLights) {
            const bossLights = this.spawnManager.enemyPool.instancedRenderer.bossLights;
            if (this.instanceIndex !== undefined && bossLights[this.instanceIndex]) {
                this.scene.remove(bossLights[this.instanceIndex]);
                delete bossLights[this.instanceIndex];
            }
        }
    }
    
    // Enhanced damage flash visual feedback
    showDamageFlash() {
        // Clean up any existing flash
        if (this.flashInterval) {
            clearInterval(this.flashInterval);
            this.flashInterval = null;
        }
        
        // Create a point light flash at the enemy's position
        const flashPosition = this.position.clone();
        flashPosition.y = 0.5; // Center height
        
        const light = new THREE.PointLight(0xffffff, 3, 3); // Brighter, wider light
        light.position.copy(flashPosition);
        this.scene.add(light);
        
        // Add to temporary lights array for cleanup
        if (!this.tempLights) this.tempLights = [];
        this.tempLights.push(light);
        
        // Fade out and remove light
        let intensity = 3.0;
        this.flashInterval = setInterval(() => {
            intensity -= 0.6;
            if (intensity <= 0 || !this.isActive) {
                clearInterval(this.flashInterval);
                this.flashInterval = null;
                this.scene.remove(light);
                // Remove from tempLights array
                this.tempLights = this.tempLights.filter(l => l !== light);
                return;
            }
            light.intensity = intensity;
        }, 20); // Faster fading for better performance
        
        // Also set a backup timeout to ensure cleanup
        setTimeout(() => {
            if (this.flashInterval) {
                clearInterval(this.flashInterval);
                this.flashInterval = null;
            }
            if (light.parent) {
                this.scene.remove(light);
                // Remove from tempLights array
                this.tempLights = this.tempLights.filter(l => l !== light);
            }
        }, 120);
    }
    
    startDyingAnimation() {
        if (this.isDying) return;
        
        this.isDying = true;
        this.deathTime = 0;
        this.deathParticlesCreated = false;
        
        // Special handling for boss death
        if (this.type === 'BOSS') {
            // Create multiple explosion effects for more dramatic boss death
            this.createBossDeathEffects();
        }
        
        // Play death sound (different for boss vs regular)
        if (this.audioManager) {
            this.audioManager.playEnemyDeath();
            
            // Extra sounds for boss
            if (this.type === 'BOSS') {
                this.audioManager.playGrenadeExplosion();
                
                // Show boss defeated message
                this.showBossDefeatedMessage();
            }
        }
        
        // Hide the instance immediately
        if (this.spawnManager && 
            this.spawnManager.enemyPool && 
            this.spawnManager.enemyPool.instancedRenderer) {
            this.spawnManager.enemyPool.instancedRenderer.hideInstance(this);
        }
    }
    
    createBossDeathEffects() {
        if (!this.spawnManager?.game?.explosionManager) return;
        
        // Create multiple explosions at different positions around the boss
        const positions = [
            this.position.clone(),
            this.position.clone().add(new THREE.Vector3(1, 0, 1)),
            this.position.clone().add(new THREE.Vector3(-1, 0, -1)),
            this.position.clone().add(new THREE.Vector3(1, 0, -1)),
            this.position.clone().add(new THREE.Vector3(-1, 0, 1))
        ];
        
        positions.forEach((pos, index) => {
            setTimeout(() => {
                this.spawnManager.game.explosionManager.createExplosion({
                    position: pos,
                    color: this.getColorByType(),
                    type: 'boss',
                    scale: this.getSizeByType() * 0.8,
                    particleCount: 30,
                    debrisCount: 15,
                    duration: 1.5,
                    addLight: true,
                    createGroundSplat: true,
                    physics: {
                        debrisVelocityMin: 5.0,
                        debrisVelocityMax: 10.0,
                        debrisGravity: 9.8,
                        debrisDrag: 0.1,
                        debrisBounce: 0.6
                    }
                });
            }, index * 200); // Stagger explosions for dramatic effect
        });
    }
    
    // Method to show boss defeated message on screen
    showBossDefeatedMessage() {
        // Create a message element
        const message = document.createElement('div');
        message.textContent = 'BOSS DEFEATED!';
        message.style.position = 'fixed';
        message.style.top = '50%';
        message.style.left = '50%';
        message.style.transform = 'translate(-50%, -50%)';
        message.style.color = '#ffaa00';
        message.style.fontSize = '48px';
        message.style.fontFamily = '"Press Start 2P", cursive';
        message.style.textShadow = '0 0 10px #880088, 0 0 20px #880088';
        message.style.zIndex = '1000';
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.5s ease-in-out';
        
        document.body.appendChild(message);
        
        // Fade in
        setTimeout(() => {
            message.style.opacity = '1';
        }, 100);
        
        // Remove after a few seconds
        setTimeout(() => {
            message.style.opacity = '0';
            setTimeout(() => {
                document.body.removeChild(message);
            }, 500);
        }, 3000);
    }
    
    updateDeathAnimation(dt) {
        // Update death animation timer
        this.deathTime += dt;
        
        // Create particle effects for death animation
        if (this.deathTime < 0.1 && !this.deathParticlesCreated) {
            this.deathParticlesCreated = true;
            this.createShaderExplosion();
        }
        
        // Update shader effects if they exist
        if (this.shaderEffects) {
            for (const effect of this.shaderEffects) {
                if (effect && effect.update) {
                    effect.update(dt);
                }
            }
        }
        
        // For boss, wait longer to ensure all effects complete
        const deathDuration = this.type === 'BOSS' ? 2.0 : 1.0;
        
        // Die after animation completes
        if (this.deathTime >= deathDuration) {
            this.die();
        }
    }
    
    createShaderExplosion() {
        // Get enemy properties for the explosion
        const enemyColor = this.getColorByType();
        const scale = this.getSizeByType() * 0.8;
        
        // If we haven't initialized the shader effects array
        if (!this.shaderEffects) {
            this.shaderEffects = [];
        }
        
        // Get the game's explosion manager from spawn manager
        if (this.spawnManager && this.spawnManager.game && this.spawnManager.game.explosionManager) {
            // Use the unified explosion manager
            const explosionEffect = this.spawnManager.game.explosionManager.createExplosion({
                position: this.position.clone(),
                color: enemyColor,
                type: this.type === 'BOSS' ? 'boss' : 'enemy',
                scale: scale,
                particleCount: this.type === 'BOSS' ? 50 : 20,
                debrisCount: this.type === 'BOSS' ? 20 : 10,
                duration: 1.0,
                hemisphereColor: new THREE.Color(enemyColor).multiplyScalar(1.5),
                createGroundSplat: false, // We'll create a splat on death instead
                // Much stronger physics settings for dramatic explosions
                physics: {
                    debrisVelocityMin: 4.0,   // Much higher min velocity for stronger outward movement
                    debrisVelocityMax: 8.0,   // Much higher max velocity for dramatic effect
                    debrisGravity: 9.8,       // Standard gravity
                    debrisDrag: 0.1,         // Lower drag for longer travel
                    debrisBounce: 0.6         // Higher bounce for more lively debris
                }
            });
            
            // Save the effect for updating during death animation
            this.shaderEffects.push(explosionEffect);
        }
    }
    
    updateBlownAwayAnimation(dt) {
        // Apply gravity to vertical velocity
        this.blownAwayVelocity.y -= this.gravity * dt;
        
        // Move position based on velocity
        this.position.add(this.blownAwayVelocity.clone().multiplyScalar(dt));
        
        // Create particles as the enemy is blown away
        if (Math.random() < 0.2) { // Random particle emission
            this.createDebrisParticle();
        }
        
        // Die when hits the ground or after a maximum time
        if (this.position.y <= 0.2 || this.deathTime > 3.0) {
            this.position.y = 0.2; // Ensure on ground
            this.die();
        }
        
        // Track time
        this.deathTime += dt;
    }
    
    createDebrisParticle() {
        // Create a small debris particle at the enemy's position
        const particleGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
            const particleMaterial = new THREE.MeshBasicMaterial({
            color: this.getColorByType(),
                transparent: true,
                opacity: 0.9
            });
            
            const particle = new THREE.Mesh(particleGeometry, particleMaterial);
            
        // Position at enemy with small random offset
        particle.position.copy(this.position).add(
            new THREE.Vector3(
                (Math.random() - 0.5) * 0.5,
                Math.random() * 0.3,
                (Math.random() - 0.5) * 0.5
            )
        );
        
        // Random direction and velocity
        const velocity = new THREE.Vector3(
            (Math.random() - 0.5) * 0.05,
            Math.random() * 0.05,
            (Math.random() - 0.5) * 0.05
        );
        
            particle.userData = {
            velocity,
                gravity: -0.005,
            lifetime: 0.5 + Math.random() * 0.5,
            age: 0
            };
            
            this.scene.add(particle);
        
        // Animate and remove
        const animateParticle = () => {
            particle.userData.age += 0.016;
            
                if (particle.userData.age >= particle.userData.lifetime) {
                    this.scene.remove(particle);
                particleGeometry.dispose();
                particleMaterial.dispose();
                    return;
                }
                
            // Apply gravity
                particle.userData.velocity.y += particle.userData.gravity;
                
                // Move particle
                particle.position.add(particle.userData.velocity);
                
                // Floor collision
                if (particle.position.y < 0.1) {
                    particle.position.y = 0.1;
                particle.userData.velocity.y = -particle.userData.velocity.y * 0.6;
                particle.userData.velocity.x *= 0.8;
                particle.userData.velocity.z *= 0.8;
                }
                
                // Fade out
                const remainingLife = 1 - (particle.userData.age / particle.userData.lifetime);
            particleMaterial.opacity = remainingLife;
                
                // Spin
            particle.rotation.x += 0.1;
            particle.rotation.y += 0.1;
            
            requestAnimationFrame(animateParticle);
        };
        
        animateParticle();
    }
    
    die() {
        if (!this.isActive) return;
        
        this.isActive = false;
        
        // Special cleanup for boss
        if (this.type === 'BOSS') {
            this.cleanupBossEffects();
        }
        
        // Notify spawn manager that enemy is defeated
        if (this.spawnManager) {
            this.spawnManager.enemyDefeated();
            
            // Create a ground splat where the enemy died
            if (this.spawnManager.decalManager) {
                // Position the splat at the enemy's position, but on the ground
                const splatPosition = new THREE.Vector3(
                    this.position.x,
                    0.02, // Just above ground
                    this.position.z
                );
                
                // Use the enemy's color for the splat
                const splatColor = this.getColorByType();
                
                // Size based on enemy type
                const splatSize = this.getSizeByType() * 1.2;
                
                // Create the ground splat
                this.spawnManager.decalManager.createGroundSplat(splatPosition, splatSize, splatColor);
            }
        }
        
        // Release the instance if it hasn't been released yet
        if (this.instanceIndex !== undefined && 
            this.spawnManager && 
            this.spawnManager.enemyPool &&
            this.spawnManager.enemyPool.instancedRenderer) {
            
            const typeKey = this.spawnManager.enemyPool.instancedRenderer.getTypeKey(this.type);
            
            // Check if the instance is actually still tracked before trying to release
            if (this.spawnManager.enemyPool.instancedRenderer.usedIndices[typeKey].has(this.instanceIndex)) {
                this.spawnManager.enemyPool.instancedRenderer.releaseInstance(this);
            } else {
                // Already released - just clear the reference
                this.instanceIndex = undefined;
            }
        }
        
        // Clean up any remaining effects
        if (this.shaderEffects) {
            for (const effect of this.shaderEffects) {
                if (effect && effect.cleanup) {
                    effect.cleanup();
                }
            }
            this.shaderEffects = [];
        }
        
        // If this enemy was marked for recycling, return it to the pool
        if (this.isMarkedForRecycling && this.spawnManager && this.spawnManager.enemyPool) {
            this.isMarkedForRecycling = false;
            this.deactivate(); // Ensure cleanup
            this.spawnManager.enemyPool.pool.push(this);
        }
    }
    
    getPosition() {
        return this.position;
    }
    
    getBoundingRadius() {
        // Adjust bounding radius based on enemy shape
        const baseSize = this.getSizeByType();
        let scaleFactor;
        
        switch(this.type) {
            case 'BOSS':
                // Make boss much easier to hit by increasing collision radius
                scaleFactor = 2.0; // Increased from 1.0
                break;
            case 'CHUBBY':
                // Use the wider dimension for chubby enemies
                scaleFactor = 1.5;
                break;
            case 'THIN':
                // Increase collision radius for thin enemies to make them easier to hit
                scaleFactor = 1.5;
                break;
            default: // REGULAR
                // Use average dimension for regular enemies
                scaleFactor = 1.0;
        }
        
        // Increase the overall multiplier to make all enemies easier to hit
        const radius = baseSize * scaleFactor * 1.0;
        return radius;
    }
    
    // Check if enough time has passed since the last shot
    canShoot() {
        const now = Date.now();
        return now - this.lastShotTime >= this.shootingCooldown;
    }
    
    tryShoot(direction) {
        const now = Date.now();
        
        // Check if cooldown has passed
        if (now - this.lastShotTime < this.shootingCooldown) {
            return;
        }
        
        // Get distance to player to make sure we're not too close
        const playerPosition = this.spawnManager && this.spawnManager.player ? 
            this.spawnManager.player.getPosition() : null;
        
        if (playerPosition) {
            const distanceToPlayer = this.position.distanceTo(playerPosition);
            const optimalDistance = this.getOptimalShootingDistance();
            
            // Only shoot if we're at a reasonable distance - not too close, not too far
            if (distanceToPlayer < optimalDistance * 0.5 || distanceToPlayer > this.shootingRange) {
                return; // Too close or too far to shoot effectively
            }
        }
        
        // 50% chance to shoot when cooldown is ready - adds unpredictability
        if (Math.random() < 0.5) {
            this.shoot(direction);
            this.lastShotTime = now;
        }
    }
    
    shoot(direction) {
        // Create bullet position at gun tip
        const bulletPosition = this.position.clone();
        
        // Set height based on enemy type 
        if (this.type === 'BOSS') {
            bulletPosition.y = 1.5; // Boss bullets start at higher position
        } else {
            bulletPosition.y = 0.5; // Standard height for regular enemies
        }
        
        // Add offset in facing direction
        const offset = direction.clone().multiplyScalar(SIZES.PLAYER + 0.3);
        bulletPosition.add(offset);
        
        // Get player's current position and velocity if available
        let adjustedDirection = direction.clone();
        if (this.spawnManager && this.spawnManager.player) {
            const player = this.spawnManager.player;
            const playerPosition = player.getPosition();
            const playerVelocity = player.velocity;
            
            // Only apply predictive aiming if player is moving and not standing still
            if (playerVelocity && playerVelocity.lengthSq() > 0.1) {
                // Calculate time it would take for the bullet to reach player
                const distanceToPlayer = this.position.distanceTo(playerPosition);
                const bulletSpeed = GAME.SPEEDS.BULLET;
                const timeToHit = distanceToPlayer / bulletSpeed;
                
                // Predict where the player will be
                const predictedPosition = playerPosition.clone().add(
                    playerVelocity.clone().multiplyScalar(timeToHit * 0.5) // Scale down prediction for balance
                );
                
                // Adjust aim direction toward the predicted position
                adjustedDirection = new THREE.Vector3()
                    .subVectors(predictedPosition, bulletPosition)
                    .normalize();
            }
            
            // Add slight randomness based on enemy type for aiming accuracy
            let inaccuracy = 0;
            switch(this.type) {
                case 'CHUBBY':
                    inaccuracy = 0.12; // Least accurate
                    break;
                case 'THIN':
                    inaccuracy = 0.05; // Most accurate
                    break;
                case 'BOSS':
                    inaccuracy = 0.07; // Boss accuracy
                    break;
                default: // REGULAR
                    inaccuracy = 0.08; // Medium accuracy
            }
            
            // Apply randomness to direction
            adjustedDirection.x += (Math.random() - 0.5) * inaccuracy;
            adjustedDirection.z += (Math.random() - 0.5) * inaccuracy;
            adjustedDirection.normalize();
        }
        
        // Create and add bullet with appropriate speed based on enemy type
        // Thin enemies shoot faster bullets, chubby enemies shoot slower bullets
        let bulletSpeedMultiplier = 0.5; // Base speed multiplier (was 0.2)
        switch(this.type) {
            case 'CHUBBY':
                bulletSpeedMultiplier = 0.4; // Slower bullets
                break;
            case 'THIN':
                bulletSpeedMultiplier = 0.65; // Faster bullets
                break;
            case 'BOSS':
                bulletSpeedMultiplier = 0.7; // Boss bullets - faster
                break;
        }
        
        // Create optimized bullet with appropriate color based on enemy type
        const bulletColor = this.getColorByType();
        const bullet = new OptimizedBullet(this.scene, bulletPosition, adjustedDirection, bulletSpeedMultiplier, this.spawnManager.decalManager, false, bulletColor);
        
        if (this.spawnManager) {
            this.spawnManager.addEnemyBullet(bullet);
        }
        
        // Add muzzle flash
        this.createMuzzleFlash();
    }
    
    createMuzzleFlash() {
        // Get the position for the muzzle flash
        const flashPosition = this.position.clone();
        
        // Adjust height based on enemy type
        if (this.type === 'BOSS') {
            flashPosition.y = 1.5; // Higher for boss (matching new boss height)
        } else {
            flashPosition.y = 0.5; // Regular height for other enemies
        }
        
        // Add offset in facing direction using quaternion
        const forward = new THREE.Vector3(0, 0, 1);
        const direction = forward.clone().applyQuaternion(this.quaternion);
        
        const offset = direction.clone().multiplyScalar(SIZES.PLAYER + 0.3);
        flashPosition.add(offset);
        
        // Create flash
        const flashGeometry = new THREE.BoxGeometry(0.3, 0.3, 0.3);
        const flashMaterial = new THREE.MeshBasicMaterial({
            color: 0xffff00,
            transparent: true,
            opacity: 1.0,
            blending: THREE.AdditiveBlending
        });
        
        const flash = new THREE.Mesh(flashGeometry, flashMaterial);
        flash.position.copy(flashPosition);
        
        // Set rotation from quaternion
        flash.quaternion.copy(this.quaternion);
        
        this.scene.add(flash);
        
        // Add light
        const light = new THREE.PointLight(0xffff00, 3, 2);
        light.position.copy(flashPosition);
        this.scene.add(light);
        
        // Animate and remove
        let opacity = 1.0;
        let scale = 1.0;
        
        const animateFlash = () => {
            opacity -= 0.2;
            scale += 0.2;
            
            if (opacity <= 0) {
                this.scene.remove(flash);
                this.scene.remove(light);
                flashMaterial.dispose();
                flashGeometry.dispose();
                return;
            }
            
            flashMaterial.opacity = opacity;
            flash.scale.set(scale, scale, scale);
            light.intensity = opacity * 3;
            
            requestAnimationFrame(animateFlash);
        };
        
        animateFlash();
    }
    
    // Add a new method to handle being blown away by grenade
    blowAway(direction, strength) {
        if (!this.isActive || this.isDying || this.isBlownAway) return;
        
        this.isBlownAway = true;
        this.deathTime = 0;
        
        // Calculate initial velocity based on direction and strength
        this.blownAwayVelocity = direction.clone().multiplyScalar(strength);
        
        // Add upward component for arc
        this.blownAwayVelocity.y = Math.min(strength * 1.5, 5);
        
        // Random rotation speed
        this.blownAwayRotation.set(
            (Math.random() - 0.5) * 10, 
            (Math.random() - 0.5) * 10,
            (Math.random() - 0.5) * 10
        );
    }
    
    reset(position, type = 'REGULAR') {
        // First ensure we're completely deactivated before reuse
        // This ensures all rendering-related resources are properly cleaned up
        this.deactivate();
        
        this.position = position.clone();
        this.type = type;
        this.isActive = true;
        this.isDying = false;
        this.isBlownAway = false;
        this.deathTime = 0;
        this.health = this.getHealthByType();
        this.speed = this.getSpeedByType();
        this.shootingCooldown = this.getShootingCooldownByType();
        this.velocity.set(0, 0, 0);
        this.blownAwayVelocity.set(0, 0, 0);
        this.blownAwayRotation.set(0, 0, 0);
        this.jumpTime = Math.random() * 10; // Randomize jump animation phase
        
        // Reset rotation and quaternion
        this.rotation = 0;
        this.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.rotation);
        
        // Generate new random scale factors for regular enemies
        this.randomScale = new THREE.Vector3(
            0.8 + Math.random() * 0.4,
            0.9 + Math.random() * 0.4,
            0.8 + Math.random() * 0.4
        );
        
        // Reset tracking arrays
        this.attachedBullets = [];
        this.hitEffects = [];
        this.shaderEffects = [];
        
        // Clear deactivation flags
        this.isCompletelyDeactivated = false;
        this.isMarkedForRecycling = false;
        
        // Ensure we have no instance index yet - will be assigned during update
        this.instanceIndex = undefined;
    }
    
    deactivate() {
        // If already fully deactivated, skip
        if (this.isCompletelyDeactivated) {
            return;
        }
        
        this.isActive = false;
        
        // Clean up shader effects if they exist
        if (this.shaderEffects && this.shaderEffects.length > 0) {
            for (const effect of this.shaderEffects) {
                if (effect && effect.cleanup) {
                    effect.cleanup();
                }
            }
            this.shaderEffects = [];
        }
        
        // Release any instance rendering resources
        if (this.spawnManager && this.spawnManager.enemyPool 
            && this.spawnManager.enemyPool.instancedRenderer 
            && this.instanceIndex !== undefined) {
            
            const typeKey = this.spawnManager.enemyPool.instancedRenderer.getTypeKey(this.type);
            
            // Only release if still tracked
            if (this.spawnManager.enemyPool.instancedRenderer.usedIndices[typeKey].has(this.instanceIndex)) {
                this.spawnManager.enemyPool.instancedRenderer.releaseInstance(this);
            } else {
                // Already released - just clear the reference
                this.instanceIndex = undefined;
            }
        }
        
        // Clean up any hit effects
        for (const effect of this.hitEffects) {
            if (effect.splash) this.scene.remove(effect.splash);
            if (effect.light) this.scene.remove(effect.light);
        }
        this.hitEffects = [];
        
        // Clear any active animation timers or intervals
        if (this.flashInterval) {
            clearInterval(this.flashInterval);
            this.flashInterval = null;
        }
        
        // Remove any temporary lights that might still be in the scene
        if (this.tempLights && this.tempLights.length > 0) {
            for (const light of this.tempLights) {
                if (light && light.parent) {
                    this.scene.remove(light);
                }
            }
            this.tempLights = [];
        }
        
        // Clean up attached bullets
        for (const bulletInfo of this.attachedBullets) {
            if (bulletInfo.bullet) {
                bulletInfo.bullet.deactivate();
            }
        }
        this.attachedBullets = [];
        
        // Reset properties
        this.velocity.set(0, 0, 0);
        this.blownAwayVelocity.set(0, 0, 0);
        this.blownAwayRotation.set(0, 0, 0);
        this.isDying = false;
        this.isBlownAway = false;
        this.deathTime = 0;
        this.lastShotTime = 0;
        
        // Explicitly mark as fully deactivated to prevent reuse issues
        this.isMarkedForRecycling = false;
        this.isCompletelyDeactivated = true;
    }
}

export class Boss extends Enemy {
    constructor(scene, position, spawnManager = null) {
        // Call the Enemy constructor with the BOSS type
        super(scene, position, 'BOSS', spawnManager);
        
        // Boss-specific properties - only use single attack
        this.attackPattern = 'SINGLE';
        
        // Track shared resources for explosion effects
        this.sharedGeometries = null;
        this.sharedMaterials = null;
        if (spawnManager && spawnManager.grenadePool) {
            this.sharedGeometries = spawnManager.grenadePool.sharedGeometries;
            this.sharedMaterials = spawnManager.grenadePool.sharedMaterials;
        }
    }
    
    tryShoot(direction) {
        // Do not shoot if boss is not active or is dying
        if (!this.isActive || this.isDying || this.isBlownAway) return;
        
        const now = Date.now();
        
        // Check if enough time has passed since last shot
        if (now - this.lastShotTime < this.shootingCooldown) return;
        
        // Get distance to player to make sure we're not too close
        const playerPosition = this.spawnManager && this.spawnManager.player ? 
            this.spawnManager.player.getPosition() : null;
        
        if (playerPosition) {
            const distanceToPlayer = this.position.distanceTo(playerPosition);
            const optimalDistance = this.getOptimalShootingDistance();
            
            // Only shoot if we're at a reasonable distance - not too close, not too far
            if (distanceToPlayer < optimalDistance * 0.5 || distanceToPlayer > this.shootingRange) {
                return; // Too close or too far to shoot effectively
            }
        }
        
        // Only use single bullet attack
        this.shootSingleBullet(direction);
        
        this.lastShotTime = now;
    }
    
    shootSingleBullet(direction) {
        if (!this.isActive) return;
        
        // Calculate bullet starting position (in front of the boss, offset by radius)
        const bulletPosition = this.position.clone();
        const directionCopy = direction.clone().normalize();
        const offset = directionCopy.multiplyScalar(this.getBoundingRadius() * 1.1);
        bulletPosition.add(offset);
        // Set bullet Y to match player's center for better hit chances
        bulletPosition.y = 1.5;
        
        // Create a ShaderBossBullet with proper spawn manager reference
        const bullet = new ShaderBossBullet(
            this.scene, 
            bulletPosition, 
            direction.clone(), 
            1.0, 
            this.spawnManager.decalManager,
            this.spawnManager.audioManager,
            false,
            this.spawnManager
        );
        
        if (this.spawnManager) {
            this.spawnManager.addEnemyBullet(bullet);
        }
        
        // Play a muzzle flash effect
        this.createEnhancedMuzzleFlash(bulletPosition);
    }
    
    createEnhancedMuzzleFlash(position, size = 0.4, color = 0xffff00) {
        // Create a larger flash
        const flashGeometry = new THREE.BoxGeometry(size, size, size);
        const flashMaterial = new THREE.MeshBasicMaterial({
            color: color,
            transparent: true,
            opacity: 1.0,
            blending: THREE.AdditiveBlending
        });
        
        const flash = new THREE.Mesh(flashGeometry, flashMaterial);
        
        // Ensure muzzle flash position is at boss height
        const flashPosition = position.clone();
        // Already correctly positioned in bullet method
        
        flash.position.copy(flashPosition);
        this.scene.add(flash);
        
        // Add an intense light
        const light = new THREE.PointLight(color, 5, 5);
        light.position.copy(position);
        this.scene.add(light);
        
        // Animate and remove with more intense effect
        let opacity = 1.0;
        let scale = 1.0;
        
        const animateFlash = () => {
            opacity -= 0.1;
            scale += 0.3;
            
            if (opacity <= 0) {
                this.scene.remove(flash);
                this.scene.remove(light);
                flashMaterial.dispose();
                flashGeometry.dispose();
                return;
            }
            
            flashMaterial.opacity = opacity;
            flash.scale.set(scale, scale, scale);
            light.intensity = opacity * 5;
            
            requestAnimationFrame(animateFlash);
        };
        
        animateFlash();
    }
    
    // Override reset method to properly handle boss-specific properties
    reset(position) {
        // Call parent reset method with BOSS type
        super.reset(position, 'BOSS');
        
        // Reset boss-specific properties
        this.attackPattern = 'SINGLE';
        
        return this;
    }
}

export class EnemyPool {
    constructor(scene, spawnManager) {
        this.scene = scene;
        this.spawnManager = spawnManager;
        this.pool = []; // Inactive enemies
        this.activeEnemies = []; // Active enemies
        
        // Create instanced renderer
        this.instancedRenderer = new InstancedEnemyRenderer(scene);
        
        // Initialize pool with a few enemies
        this.initPool();
    }
    
    initPool() {
        // Pre-create a few enemies of each type for the pool
        for (let i = 0; i < 5; i++) {
            const enemy = new Enemy(this.scene, new THREE.Vector3(), 'REGULAR', this.spawnManager);
            enemy.isActive = false;
            this.pool.push(enemy);
        }
        
        // Add a boss to the pool
        const boss = new Boss(this.scene, new THREE.Vector3(), this.spawnManager);
        boss.isActive = false;
        this.pool.push(boss);
    }
    
    getEnemy(position, type = 'REGULAR') {
        // For boss, try to find an inactive boss in the pool first
        if (type === 'BOSS') {
            let boss = this.pool.find(e => !e.isActive && e instanceof Boss);
            if (boss) {
                // Remove from pool
                this.pool.splice(this.pool.indexOf(boss), 1);
            } else {
                // Create a new boss
                boss = new Boss(this.scene, position, this.spawnManager);
            }
            
            // Reset boss properties
            boss.reset(position);
            
            // Assign an instance index
            const typeKey = this.instancedRenderer.getTypeKey(type);
            boss.instanceIndex = this.instancedRenderer.getNextIndex(typeKey);
            
            // Add to active enemies
            this.activeEnemies.push(boss);
            
            return boss;
        }
        
        // For regular enemies
        let enemy = this.pool.find(e => !e.isActive);
        
        // If no enemy is available, create a new one or grow the pool
        if (!enemy) {
            if (this.pool.length + this.activeEnemies.length < 100) { // Increase cap to 100
                enemy = new Enemy(this.scene, position, type, this.spawnManager);
            } else {
                // Take the oldest enemy from active enemies
                enemy = this.activeEnemies.shift();
            }
        } else {
            // Remove from pool
            this.pool.splice(this.pool.indexOf(enemy), 1);
        }
        
        // Reset and reposition the enemy
        enemy.reset(position, type);
        
        // Assign an instance index
        const typeKey = this.instancedRenderer.getTypeKey(type);
        enemy.instanceIndex = this.instancedRenderer.getNextIndex(typeKey);
        
        // Add to active enemies
        this.activeEnemies.push(enemy);
        
        return enemy;
    }
    
    recycleEnemy(enemy) {
        // Skip if enemy is already in the pool
        if (this.pool.includes(enemy)) {
            // Removed warning log
            return;
        }
        
        // Remove from active enemies if it's there
        const index = this.activeEnemies.indexOf(enemy);
        if (index !== -1) {
            this.activeEnemies.splice(index, 1);
        } else {
            // Enemy is not in active list - this shouldn't happen
            // Removed warning log
        }
        
        // If the enemy is in the dying animation, let it finish before recycling
        // But explicitly mark it for deactivation when the death animation completes
        if (enemy.isDying) {
            // Mark enemy for recycling but let the death animation complete
            enemy.isMarkedForRecycling = true;
            
            // Ensure the instance is hidden during death animation
            if (this.instancedRenderer && enemy.instanceIndex !== undefined) {
                // Verify the instance is still tracked before hiding
                const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
                if (this.instancedRenderer.usedIndices[typeKey].has(enemy.instanceIndex)) {
                    this.instancedRenderer.hideInstance(enemy);
                }
            }
            
            return;
        }
        
        // Release instance immediately if we have one
        if (this.instancedRenderer && enemy.instanceIndex !== undefined) {
            const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
            // Only release if the instance is still tracked
            if (this.instancedRenderer.usedIndices[typeKey].has(enemy.instanceIndex)) {
                this.instancedRenderer.releaseInstance(enemy);
            } else {
                // Already released - just clear the reference
                enemy.instanceIndex = undefined;
            }
        }
        
        // Ensure the enemy is fully deactivated (cleans up other resources)
        enemy.deactivate();
        
        // Add back to pool
        this.pool.push(enemy);
    }
    
    // New method to update an enemy's instance in the renderer
    updateEnemyInstance(enemy) {
        if (this.instancedRenderer) {
            this.instancedRenderer.updateEnemy(enemy);
        }
    }
    
    // Add a new method for full system validation
    validateInstanceSystem() {
        if (!this.instancedRenderer) return;
        
        // Removed verbose log
        
        // Create a list to track enemies that need new indices
        const enemiesNeedingNewIndices = [];
        
        // 1. Check all active enemies to ensure their indices are valid
        for (let i = 0; i < this.activeEnemies.length; i++) {
            const enemy = this.activeEnemies[i];
            
            // Skip dying enemies or blown away enemies (they should be hidden)
            if (enemy.isDying || enemy.isBlownAway) continue;
            
            if (!enemy.isActive) {
                // Enemy is in active list but not active - recycle immediately
                // Removed warning log
                this.recycleEnemy(enemy);
                continue;
            }
            
            // Check if index is valid
            const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
            if (enemy.instanceIndex === undefined || 
                !this.instancedRenderer.usedIndices[typeKey].has(enemy.instanceIndex) ||
                enemy.instanceIndex >= this.instancedRenderer.instancedMeshes[typeKey].body.count) {
                
                // Don't immediately assign new index - collect for bulk processing
                enemiesNeedingNewIndices.push(enemy);
            }
        }
        
        // 2. Synchronize the used indices sets with the active enemies
        ['regular', 'chubby', 'thin', 'boss'].forEach(typeKey => {
            // Reset the usedIndices to only include valid ones
            const oldIndices = new Set(this.instancedRenderer.usedIndices[typeKey]);
            this.instancedRenderer.usedIndices[typeKey].clear();
            
            // Re-add only indices that match active non-dying enemies
            let validIndicesCount = 0;
            for (const enemy of this.activeEnemies) {
                if (enemy.isActive && 
                    !enemy.isDying && 
                    !enemy.isBlownAway && 
                    this.instancedRenderer.getTypeKey(enemy.type) === typeKey && 
                    enemy.instanceIndex !== undefined && 
                    oldIndices.has(enemy.instanceIndex)) {
                    
                    this.instancedRenderer.usedIndices[typeKey].add(enemy.instanceIndex);
                    validIndicesCount++;
                }
            }
            
            // Removed per-type log
        });
        
        // 3. Assign new indices to enemies that need them
        if (enemiesNeedingNewIndices.length > 0 && enemiesNeedingNewIndices.length > 5) {
            // Only log if we have a significant issue (more than 5 enemies)
            console.log(`Fixing ${enemiesNeedingNewIndices.length} invalid indices`);
            
            for (const enemy of enemiesNeedingNewIndices) {
                const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
                enemy.instanceIndex = this.instancedRenderer.getNextIndex(typeKey);
            }
        }
        else {
            // Just fix without logging
            for (const enemy of enemiesNeedingNewIndices) {
                const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
                enemy.instanceIndex = this.instancedRenderer.getNextIndex(typeKey);
            }
        }
        
        return {
            enemiesFixed: enemiesNeedingNewIndices.length,
            totalActiveEnemies: this.activeEnemies.length
        };
    }
    
    // Method for emergency full reset of the instance system
    fullReset() {
        // Only log critical system events
        console.warn("Emergency reset");
        
        // 1. Collect all enemies (active and pooled)
        const allEnemies = [...this.activeEnemies, ...this.pool];
        
        // 2. Fully deactivate all enemies
        for (const enemy of allEnemies) {
            enemy.deactivate();
        }
        
        // 3. Clear the active enemies list
        this.activeEnemies = [];
        
        // 4. Reset the instance renderer
        if (this.instancedRenderer) {
            // Reset all used indices
            ['regular', 'chubby', 'thin', 'boss'].forEach(type => {
                this.instancedRenderer.usedIndices[type].clear();
            });
            
            // Hide all instances
            for (const type of ['regular', 'chubby', 'thin', 'boss']) {
                const mesh = this.instancedRenderer.instancedMeshes[type].body;
                const gunMesh = this.instancedRenderer.instancedMeshes[type].gun;
                const count = mesh.count;
                
                // Set all to invisible
                const zeroMatrix = new THREE.Matrix4().makeScale(0, 0, 0);
                for (let i = 0; i < count; i++) {
                    mesh.setMatrixAt(i, zeroMatrix);
                    gunMesh.setMatrixAt(i, zeroMatrix);
                    
                    if (type === 'boss' && this.instancedRenderer.instancedMeshes[type].emblem) {
                        this.instancedRenderer.instancedMeshes[type].emblem.setMatrixAt(i, zeroMatrix);
                    }
                }
                
                // Update matrices
                mesh.instanceMatrix.needsUpdate = true;
                gunMesh.instanceMatrix.needsUpdate = true;
                
                if (type === 'boss' && this.instancedRenderer.instancedMeshes[type].emblem) {
                    this.instancedRenderer.instancedMeshes[type].emblem.instanceMatrix.needsUpdate = true;
                }
                
                // Clean up boss lights
                if (type === 'boss') {
                    for (const lightId in this.instancedRenderer.bossLights) {
                        const light = this.instancedRenderer.bossLights[lightId];
                        this.scene.remove(light);
                    }
                    this.instancedRenderer.bossLights = {};
                }
            }
        }
        
        // 5. Put all enemies back in the pool
        this.pool = allEnemies;
        
        // 6. Run validation once more 
        this.validateInstanceSystem();
        
        // Removed completion log
        
        return {
            enemiesReset: allEnemies.length,
            enemiesInPool: this.pool.length,
            activeEnemies: this.activeEnemies.length
        };
    }
    
    // Detect if system has persistent errors and needs a reset
    detectSystemFailure() {
        let errorCount = 0;
        
        // Check for enemies with invalid instance indices
        for (const enemy of this.activeEnemies) {
            if (enemy.isActive && !enemy.isDying && !enemy.isBlownAway) {
                const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
                if (enemy.instanceIndex === undefined || 
                    !this.instancedRenderer.usedIndices[typeKey].has(enemy.instanceIndex) ||
                    enemy.instanceIndex >= this.instancedRenderer.instancedMeshes[typeKey].body.count) {
                    errorCount++;
                }
            }
        }
        
        // If more than 5 enemies have invalid indices, we have a systemic issue
        return errorCount > 5;
    }
    
    update(dt, playerPosition) {
        // Periodically validate the entire instance system
        if (Math.random() < 0.01) { // ~1% chance per frame
            this.validateInstanceSystem();
            
            // Check if we have too many errors and need a full reset
            if (this.detectSystemFailure()) {
                // Emergency reset of the entire system
                this.fullReset();
            }
        }
        
        // Update all active enemies
        for (let i = this.activeEnemies.length - 1; i >= 0; i--) {
            const enemy = this.activeEnemies[i];
            
            // Skip updating if enemy is no longer active or has completed its death animation
            if (!enemy.isActive || (enemy.isDying && enemy.deathTime >= (enemy.type === 'BOSS' ? 2.0 : 1.0))) {
                this.recycleEnemy(enemy);
                continue;
            }
            
            // Additional check for boss - ensure it's not in the list if it should be dead
            if (enemy.type === 'BOSS' && enemy.health <= 0 && !enemy.isDying) {
                // Force set isDying to ensure the death animation starts
                enemy.startDyingAnimation();
            }
            
            // Validate instance index before update
            if (enemy.instanceIndex === undefined && 
                !enemy.isDying && 
                !enemy.isBlownAway && 
                this.instancedRenderer) {
                // Enemy is missing an instance index - assign one
                const typeKey = this.instancedRenderer.getTypeKey(enemy.type);
                enemy.instanceIndex = this.instancedRenderer.getNextIndex(typeKey);
            }
            
            // Update the enemy
            enemy.update(dt, playerPosition);
            
            // Check again if enemy is no longer active after update
            if (!enemy.isActive) {
                this.recycleEnemy(enemy);
            }
        }
        
        // Batch update all instance matrices at once
        if (this.instancedRenderer) {
            this.instancedRenderer.batchUpdate();
        }
        
        return this.activeEnemies;
    }
    
    cleanup() {
        // Cleanup all enemies in the pool
        for (const enemy of this.pool) {
            enemy.deactivate();
        }
        
        // Cleanup all active enemies
        for (const enemy of this.activeEnemies) {
            enemy.deactivate();
        }
        
        // Cleanup the instanced renderer
        if (this.instancedRenderer) {
            this.instancedRenderer.cleanup();
        }
        
        this.pool = [];
        this.activeEnemies = [];
    }
} 