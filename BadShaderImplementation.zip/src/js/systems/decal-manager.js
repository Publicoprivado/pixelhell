import * as THREE from 'three';
import { COLORS } from '../utils/constants.js';

export class DecalManager {
    constructor(scene) {

        this.scene = scene;
        this.decals = [];
        this.maxDecals = 200; // Increased from 80 to allow more persistent decals
        
        // Create textures for decals
        this.createDecalTextures();
        
        // Function to darken a color
        this.darkenColor = (color) => {
            const c = new THREE.Color(color);
            // Darken by reducing RGB values by 40%
            c.r *= 0.1;
            c.g *= 0.1;
            c.b *= 0.1;
            return c.getHex();
        };
        
        // Create shared materials for better performance
        this.sharedMaterials = {
            bullet: new THREE.MeshBasicMaterial({
                map: this.decalTexture,
                transparent: true,
                opacity: 1.0,
                depthTest: true, 
                depthWrite: false,
                color: this.darkenColor(COLORS.BULLET),
                side: THREE.DoubleSide
            }),
            grenade: new THREE.MeshBasicMaterial({
                map: this.decalTexture,
                transparent: true,
                opacity: 1.0,
                depthTest: true, 
                depthWrite: false,
                color: this.darkenColor(0x9B870C), // Darker yellow for grenades
                side: THREE.DoubleSide
            })
        };
        
        // Create reusable geometries
        this.geometries = {
            circle: new THREE.CircleGeometry(1, 32) // Single circle geometry with 32 segments
        };
        
        // Start auto-cleanup for magenta splats
        this.startAutoCleanup();
    }

    createDecalTextures() {
        // Create a simple circular decal texture
        const canvas = document.createElement('canvas');
        canvas.width = 256;
        canvas.height = 256;
        const context = canvas.getContext('2d');
        
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = canvas.width * 0.4; // 80% of canvas size for clean circle
        
        // Draw a clean circle
        context.fillStyle = '#fff';
        context.beginPath();
        context.arc(centerX, centerY, radius, 0, Math.PI * 2);
        context.fill();
        
        // Add a slight gradient for some depth
        const gradient = context.createRadialGradient(
            centerX, centerY, 0,
            centerX, centerY, radius
        );
        gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
        gradient.addColorStop(0.8, 'rgba(255, 255, 255, 0.9)');
        gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        
        context.fillStyle = gradient;
        context.beginPath();
        context.arc(centerX, centerY, radius, 0, Math.PI * 2);
        context.fill();
        
        // Create texture
        this.decalTexture = new THREE.CanvasTexture(canvas);
        this.decalTexture.needsUpdate = true;
    }

    // Create a decal on a surface (rocks, trees, etc.)
    createSurfaceDecal(position, normal, object, color = null) {
        // Check if we're at capacity before creating a new decal
        if (this.decals.length >= this.maxDecals) {
            this.removeOldestDecal();
        }
        
        // Determine which material to use
        let material;
        if (color === 0x9B870C) { // Yellow/grenade color
            material = this.sharedMaterials.grenade;
        } else if (color === COLORS.BULLET || color === null) { // Default magenta
            material = this.sharedMaterials.bullet;
        } else {
            // Create a custom material with darkened color
            material = new THREE.MeshBasicMaterial({
                map: this.decalTexture,
                transparent: true,
                opacity: 0.8,
                depthTest: true, 
                depthWrite: false,
                color: this.darkenColor(color),
                side: THREE.DoubleSide
            });
        }
        
        // Use shared circle geometry and appropriate material
        const decal = new THREE.Mesh(this.geometries.circle, material);
        
        // Use a consistent size
        const size = 0.4; // Smaller size for surface hits
        decal.scale.set(size, size, size);
        
        // Position at hit point
        decal.position.copy(position);
        
        // Orient to surface normal
        if (normal) {
            decal.lookAt(position.clone().add(normal));
            decal.position.add(normal.clone().multiplyScalar(0.02)); // Slightly offset to prevent z-fighting
        }
        
        // Add to scene
        this.scene.add(decal);
        
        // Store in decals array with timestamp
        this.decals.push({
            mesh: decal,
            timestamp: Date.now(),
            type: 'surface',
            isCustomColor: color !== null && color !== COLORS.BULLET && color !== 0x9B870C
        });
        
        return decal;
    }
    
    // Create a decal on the ground using simple circle
    createGroundSplat(position, size = 0.7, color = null) {
        // Check if we're at capacity before creating a new decal
        if (this.decals.length >= this.maxDecals) {
            this.removeOldestDecal();
        }
        
        // Create a simple circle geometry
        const geometry = new THREE.CircleGeometry(1, 32); // Use 32 segments for smoother circle
        
        // Choose appropriate material based on color
        let material;
        if (color === 0x9B870C) { // Yellow/grenade color
            material = this.sharedMaterials.grenade;
        } else if (color === COLORS.BULLET || color === null) { // Default magenta
            material = this.sharedMaterials.bullet;
        } else {
            // Create a custom material with darkened color
            material = new THREE.MeshBasicMaterial({
                map: this.decalTexture,
                transparent: true,
                opacity: 0.8,
                depthTest: true, 
                depthWrite: false,
                color: this.darkenColor(color),
                side: THREE.DoubleSide
            });
        }
        
        const splat = new THREE.Mesh(geometry, material);
        
        // Scale to match requested size
        splat.scale.set(size, size, size);
        
        // Position at hit point, slightly above ground
        splat.position.copy(position);
        splat.position.y = 0.02; // Just above ground to avoid z-fighting
        
        // Orient facing up
        splat.rotation.x = -Math.PI / 2;
        
        // Add to scene
        this.scene.add(splat);
        
        // Store in decals array with timestamp and color info
        this.decals.push({
            mesh: splat,
            timestamp: Date.now(),
            type: 'ground',
            isCustomColor: color !== null && color !== COLORS.BULLET && color !== 0x9B870C
        });
        
        return splat;
    }
    
    // Remove the oldest decal immediately
    removeOldestDecal() {
        if (this.decals.length === 0) return;
        
        // Find the oldest decal
        let oldestIndex = 0;
        let oldestTime = Infinity;
        
        for (let i = 0; i < this.decals.length; i++) {
            if (this.decals[i].timestamp < oldestTime) {
                oldestTime = this.decals[i].timestamp;
                oldestIndex = i;
            }
        }
        
        // Remove the oldest decal
        const decal = this.decals[oldestIndex];
        if (decal && decal.mesh) {
            this.scene.remove(decal.mesh);
            
            // Dispose custom materials
            if (decal.isCustomColor && decal.mesh.material) {
                decal.mesh.material.dispose();
            }
            
            this.decals.splice(oldestIndex, 1);
        }
    }
    
    // Prune old decals when we exceed the maximum
    pruneDecals() {
        // This is now handled directly in createGroundSplat and createSurfaceDecal
        // But we keep it for compatibility with existing code
        if (this.decals.length > this.maxDecals) {
            // Remove oldest decals
            const numToRemove = this.decals.length - this.maxDecals;
            
            // Sort by timestamp (oldest first)
            this.decals.sort((a, b) => a.timestamp - b.timestamp);
            
            for (let i = 0; i < numToRemove; i++) {
                const decal = this.decals[i];
                if (decal && decal.mesh) {
                    this.scene.remove(decal.mesh);
                    
                    // Dispose custom materials
                    if (decal.isCustomColor && decal.mesh.material) {
                        decal.mesh.material.dispose();
                    }
                }
            }
            
            // Remove from array
            this.decals.splice(0, numToRemove);
        }
    }
    
    // Clean up all decals
    cleanUp() {
        for (const decal of this.decals) {
            if (decal && decal.mesh) {
                this.scene.remove(decal.mesh);
                
                // Dispose custom materials
                if (decal.isCustomColor && decal.mesh.material) {
                    decal.mesh.material.dispose();
                }
            }
        }
        this.decals = [];
        
        // Dispose of shared resources
        for (const key in this.geometries) {
            if (this.geometries[key]) {
                this.geometries[key].dispose();
            }
        }
        
        for (const key in this.sharedMaterials) {
            if (this.sharedMaterials[key]) {
                this.sharedMaterials[key].dispose();
            }
        }
        
        if (this.decalTexture) {
            this.decalTexture.dispose();
        }
    }
    
    // Start the automatic cleanup of decals
    startAutoCleanup() {
        // Check every minute for old decals
        setInterval(() => {
            const now = Date.now();
            
            // Filter out decals older than 10 minutes (increased from 30 seconds)
            const timeThreshold = 10 * 60 * 1000; // 10 minutes in milliseconds
            
            const oldDecals = this.decals.filter(decal => {
                return (now - decal.timestamp) > timeThreshold;
            });
            
            // Only remove up to 10 decals at a time to avoid frame drops
            const maxToRemove = Math.min(oldDecals.length, 10);
            for (let i = 0; i < maxToRemove; i++) {
                const decal = oldDecals[i];
                if (decal && decal.mesh) {
                    this.scene.remove(decal.mesh);
                    
                    // Dispose custom materials
                    if (decal.isCustomColor && decal.mesh.material) {
                        decal.mesh.material.dispose();
                    }
                    
                    // Remove from original array
                    const index = this.decals.indexOf(decal);
                    if (index !== -1) {
                        this.decals.splice(index, 1);
                    }
                }
            }
        }, 60000); // Check every minute
    }
} 
