import * as THREE from 'three';
import { createShaderExplosion, createExplosionMaterial, createDebrisParticlesMaterial } from '../utils/shaders.js';

/**
 * ExplosionManager - A unified system for creating and managing explosions throughout the game.
 * Handles all types of explosions (enemy deaths, grenades, boss projectiles) with consistent physics and effects.
 */
export class ExplosionManager {
    constructor(scene, decalManager, audioManager) {
        this.scene = scene;
        this.decalManager = decalManager;
        this.audioManager = audioManager;
        this.activeExplosions = [];
        this.explosionCount = 0;
        
        // Performance settings
        this.maxSimultaneousExplosions = 5;
        this.cullingDistance = 100; // Greatly increased from 30 to prevent effects from disappearing
        this.lastUpdateTime = 0;
        this.updateInterval = 1000 / 30; // Cap at 30fps
        
        // Performance mode (auto-adjusts based on FPS)
        this.performanceMode = 'high';
        this.fpsHistory = [];
        this.fpsHistorySize = 30;
        this.lastPerformanceCheck = 0;
        this.performanceCheckInterval = 1000; // Check every second
        
        // Cache explosion positions for distance culling
        this.cameraPosition = new THREE.Vector3();
        this.maxExplosionDistance = 100; // Increased from 40 to show full effects from much further away
        
        // Create a frustum for culling
        this.frustum = new THREE.Frustum();
        this.projScreenMatrix = new THREE.Matrix4();

        // Default physics parameters
        this.defaultPhysics = {
            debrisVelocityMin: 4.0,    // Minimum velocity for debris particles
            debrisVelocityMax: 8.0,    // Maximum velocity for debris particles
            debrisGravity: 9.8,        // Gravity effect (m/s²)
            debrisDrag: 0.1,           // Air drag coefficient (0-1)
            debrisBounce: 0.6          // Bounce factor (0-1)
        };
    }
    
    // Update method with performance monitoring (culling removed)
    update(dt, cameraPosition) {
        // Throttle updates
        const now = performance.now();
        if (now - this.lastUpdateTime < this.updateInterval) {
            return;
        }
        this.lastUpdateTime = now;

        // Check and adjust performance mode
        if (now - this.lastPerformanceCheck > this.performanceCheckInterval) {
            this.adjustPerformanceMode();
            this.lastPerformanceCheck = now;
        }

        // Update active explosions - CULLING REMOVED
        this.activeExplosions = this.activeExplosions.filter(explosion => {
            if (!explosion || !explosion.update) return false;

            // No distance culling - let all explosions render regardless of distance
            return explosion.update(dt);
        });
    }
    
    // Dynamically adjust particle counts based on performance
    adjustPerformanceMode() {
        // Calculate average FPS
        const fps = this.scene.userData?.game?.currentFps || 60;
        this.fpsHistory.push(fps);
        if (this.fpsHistory.length > this.fpsHistorySize) {
            this.fpsHistory.shift();
        }

        const avgFps = this.fpsHistory.reduce((a, b) => a + b, 0) / this.fpsHistory.length;

        // Adjust performance mode based on FPS but keep culling distances high
        if (avgFps < 30) {
            this.performanceMode = 'low';
            this.maxSimultaneousExplosions = 3;
            this.cullingDistance = 80; // Increased from 20
        } else if (avgFps < 45) {
            this.performanceMode = 'medium';
            this.maxSimultaneousExplosions = 4;
            this.cullingDistance = 90; // Increased from 25
        } else {
            this.performanceMode = 'high';
            this.maxSimultaneousExplosions = 5;
            this.cullingDistance = 100; // Increased from 30
        }
    }
    
    // Get particle count based on current performance mode and distance from camera
    getParticleCount(baseCount, position) {
        // Apply performance mode scaling
        let count = baseCount;
        if (this.performanceMode === 'low') {
            count = Math.floor(baseCount * 0.4); // 40% of particles in low mode
        } else if (this.performanceMode === 'medium') {
            count = Math.floor(baseCount * 0.7); // 70% of particles in medium mode
        }
        
        // Apply distance-based scaling if position is provided
        if (position) {
            const distance = this.cameraPosition.distanceTo(position);
            
            // Scale particles based on distance
            if (distance > this.maxExplosionDistance) {
                // Reduce particles linearly as distance increases
                const distanceFactor = Math.max(0.1, 1 - ((distance - this.maxExplosionDistance) / this.maxExplosionDistance));
                count = Math.floor(count * distanceFactor);
            }
        }
        
        // Ensure minimum count
        return Math.max(5, count);
    }
    
    // Create explosion at specified position with options
    createExplosion(options = {}) {
        // Check if we're at the explosion limit
        if (this.activeExplosions.length >= this.maxSimultaneousExplosions) {
            // Find the oldest explosion and force cleanup
            const oldestExplosion = this.activeExplosions[0];
            if (oldestExplosion?.forceCleanup) {
                oldestExplosion.forceCleanup();
            }
            this.activeExplosions.shift();
        }

        const {
            position,
            color = 0xff5500,
            type = 'regular',
            scale = 1.0,
            particleCount = 20,
            debrisCount = 10,
            duration = 1.0,
            addLight = true,
            createGroundSplat = true,
            physics = {}
        } = options;

        // Adjust counts based on performance mode
        let scaledParticleCount = particleCount;
        let scaledDebrisCount = debrisCount;

        switch (this.performanceMode) {
            case 'low':
                scaledParticleCount = Math.floor(particleCount * 0.4);
                scaledDebrisCount = Math.floor(debrisCount * 0.3);
                break;
            case 'medium':
                scaledParticleCount = Math.floor(particleCount * 0.7);
                scaledDebrisCount = Math.floor(debrisCount * 0.6);
                break;
            // 'high' uses default values
        }

        // Ensure minimum counts
        scaledParticleCount = Math.max(5, scaledParticleCount);
        scaledDebrisCount = Math.max(2, scaledDebrisCount);

        // Create a simple circular ground splat if requested
        if (createGroundSplat && this.decalManager) {
            const splatPosition = position.clone();
            splatPosition.y = 0.02; // Slightly above ground to prevent z-fighting
            
            // Create a clean circular splat with the explosion color
            // Use a consistent size that scales with the explosion
            const splatSize = scale * 1.5; // Make splat slightly larger than explosion
            
            this.decalManager.createGroundSplat(
                splatPosition, 
                splatSize,
                color
            );
        }
        
        // Create sound if requested
        if (this.audioManager) {
            this.audioManager.playGrenadeExplosion();
        }
        
        // Create the explosion effect with adjusted parameters
        const explosion = createShaderExplosion(
            this.scene,
            position,
            {
                count: scaledParticleCount,
                color: color,
                size: this.performanceMode === 'low' ? 0.6 : 0.5, // Larger particles for fewer particles
                scale: scale,
                duration: this.performanceMode === 'low' ? duration * 0.7 : duration,
                includeDebris: this.performanceMode !== 'low',
                debrisCount: scaledDebrisCount,
                physics: {
                    ...physics,
                    // Adjust physics based on performance mode
                    debrisVelocityMin: physics.debrisVelocityMin * (this.performanceMode === 'low' ? 0.7 : 1),
                    debrisVelocityMax: physics.debrisVelocityMax * (this.performanceMode === 'low' ? 0.7 : 1),
                    debrisDrag: physics.debrisDrag * (this.performanceMode === 'low' ? 1.5 : 1)
                },
                addLight: addLight && this.performanceMode !== 'low',
                lightIntensity: this.performanceMode === 'high' ? 2.0 : 1.0,
                lightDistance: scale * (this.performanceMode === 'low' ? 2 : 3),
                type: type
            }
        );
        
        // Store position for culling
        explosion.position = position.clone();
        
        // Add to active explosions
        this.activeExplosions.push(explosion);
        this.explosionCount++;
        
        return explosion;
    }
    
    // Clean up resources
    cleanup() {
        // Force cleanup all active explosions
        this.activeExplosions.forEach(explosion => {
            if (explosion?.forceCleanup) {
                explosion.forceCleanup();
            }
        });
        this.activeExplosions = [];
        this.explosionCount = 0;
    }
} 