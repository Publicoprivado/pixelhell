// shaders.js - Collection of shader materials for optimized visual effects

import * as THREE from 'three';
import { COLORS } from './constants.js';

// Explosion shader - creates a procedural explosion effect
export const createExplosionMaterial = (color = 0xff5500, intensity = 1.0) => {
    return new THREE.ShaderMaterial({
        uniforms: {
            time: { value: 0.0 },
            color: { value: new THREE.Color(color) },
            intensity: { value: intensity }
        },
        vertexShader: `
            varying vec2 vUv;
            varying vec3 vPosition;
            
            void main() {
                vUv = uv;
                vPosition = position;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,
        fragmentShader: `
            uniform float time;
            uniform vec3 color;
            uniform float intensity;
            
            varying vec2 vUv;
            varying vec3 vPosition;
            
            float noise(vec3 p) {
                vec3 i = floor(p);
                vec4 a = dot(i, vec3(1.0, 57.0, 21.0)) + vec4(0.0, 57.0, 21.0, 78.0);
                vec3 f = fract(p);
                f = f * f * (3.0 - 2.0 * f);
                a = mix(sin(cos(a) * a), sin(cos(1.0 + a) * (1.0 + a)), f.x);
                a.xy = mix(a.xz, a.yw, f.y);
                return mix(a.x, a.y, f.z);
            }
            
            void main() {
                vec2 center = vUv - 0.5;
                float dist = length(center);
                
                // Create noise-based explosion with time animation
                float noiseVal = noise(vec3(vUv * 5.0, time * 0.5));
                float edge = 0.5 - time * 0.5;
                float alpha = smoothstep(edge + 0.1, edge, dist) * (1.0 - time);
                
                // Add noise detail
                alpha *= 1.0 - smoothstep(0.0, edge, dist - 0.1 * noiseVal);
                
                // Color gradient from center (hot) to edge (color)
                vec3 finalColor = mix(vec3(1.0, 1.0, 0.8), color, smoothstep(0.0, edge, dist));
                
                // Apply intensity
                finalColor *= intensity;
                
                gl_FragColor = vec4(finalColor, alpha);
            }
        `,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide
    });
};

// Energy projectile shader - creates a glowing energy ball with animated tendrils
export const createEnergyProjectileMaterial = (color = 0xff0088, intensity = 1.2) => {
    return new THREE.ShaderMaterial({
        uniforms: {
            time: { value: 0.0 },
            color: { value: new THREE.Color(color) },
            intensity: { value: intensity }
        },
        vertexShader: `
            varying vec2 vUv;
            varying vec3 vPosition;
            
            void main() {
                vUv = uv;
                vPosition = position;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,
        fragmentShader: `
            uniform float time;
            uniform vec3 color;
            uniform float intensity;
            
            varying vec2 vUv;
            varying vec3 vPosition;
            
            // Simplex-like noise function
            float snoise(vec3 p) {
                float n = sin(p.x * 1.0 + time * 2.0) * 0.5 + 
                          sin(p.y * 1.5 + time * 1.5) * 0.5 + 
                          sin(p.z * 0.5 + time * 1.0) * 0.5;
                return n * 0.5 + 0.5;
            }
            
            void main() {
                vec2 center = vUv - 0.5;
                float dist = length(center);
                
                // Core of the projectile
                float core = smoothstep(0.5, 0.0, dist);
                
                // Animated energy tendrils
                float noise1 = snoise(vec3(vUv * 8.0, time));
                float noise2 = snoise(vec3(vUv * 5.0, time * 0.5 + 10.0));
                
                // Tendrils that move outward
                float tendrils = smoothstep(0.45, 0.0, dist - 0.1 * noise1 * noise2);
                
                // Pulsing outer glow
                float pulse = (sin(time * 3.0) * 0.5 + 0.5) * 0.2;
                float glow = smoothstep(0.5 + pulse, 0.1, dist);
                
                // Combine effects
                float alpha = core + tendrils * 0.7 + glow * 0.3;
                
                // Color variation
                vec3 finalColor = mix(vec3(1.0), color, smoothstep(0.2, 0.5, dist));
                
                // Brighten the center
                finalColor = mix(finalColor, vec3(1.0, 1.0, 1.0), core * 0.7);
                
                // Apply intensity
                finalColor *= intensity * (1.0 + pulse * 0.5);
                
                gl_FragColor = vec4(finalColor, alpha);
            }
        `,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide
    });
};

// Particle system shader - efficient way to render multiple particles
export const createParticleSystemMaterial = (color = 0xff0000, size = 0.5) => {
    return new THREE.ShaderMaterial({
        uniforms: {
            time: { value: 0.0 },
            color: { value: new THREE.Color(color) },
            pointSize: { value: size }
        },
        vertexShader: `
            uniform float time;
            uniform float pointSize;
            
            attribute float size;
            attribute vec3 velocity;
            attribute float offset;
            
            varying float vAlpha;
            
            void main() {
                // Apply velocity and gravity effect
                vec3 pos = position + velocity * (time + offset) + vec3(0.0, -0.5 * (time + offset) * (time + offset), 0.0);
                
                // Calculate distance-based alpha
                float life = time + offset;
                vAlpha = 1.0 - smoothstep(0.0, 1.0, life);
                
                // Calculate particle size based on life
                float particleSize = size * pointSize * (1.0 - life * 0.5);
                
                gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
                gl_PointSize = particleSize / gl_Position.w;
            }
        `,
        fragmentShader: `
            uniform vec3 color;
            
            varying float vAlpha;
            
            void main() {
                // Create circular particle shape
                vec2 center = gl_PointCoord - 0.5;
                float dist = length(center);
                if (dist > 0.5) discard;
                
                // Smooth edge
                float alpha = vAlpha * smoothstep(0.5, 0.3, dist);
                
                // Gradient from center to edge
                vec3 finalColor = mix(vec3(1.0), color, smoothstep(0.0, 0.5, dist));
                
                gl_FragColor = vec4(finalColor, alpha);
            }
        `,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true
    });
};

// Update the time uniform for shader materials
export const updateShaderMaterial = (material, deltaTime) => {
    // Add comprehensive null checks to prevent trying to update disposed material uniforms
    if (!material || !material.uniforms) return false;
    
    try {
        // Only update if the time uniform exists and the material hasn't been disposed
        if (material.uniforms.time !== undefined && material.uniforms.time !== null) {
            material.uniforms.time.value += deltaTime;
            return true;
        }
    } catch (error) {
        console.warn('Error updating shader material, may have been disposed:', error.message);
        return false;
    }
    
    return false;
};

// Function to create a particle explosion using the shader-based approach
export const createShaderExplosion = (scene, position, options = {}) => {
    const {
        count = 20,
        color = 0xff5500,
        hemisphereColor = null, // New option for separate hemisphere color
        size = 0.5,
        scale = 1.0,
        duration = 1.0,
        includeDebris = true,  // Option to include debris particles
        debrisCount = 10,      // Number of debris particles
        physics = {            // Physics parameters with defaults
            debrisVelocityMin: 1.5,   // Min velocity multiplier for debris
            debrisVelocityMax: 3.0,   // Max velocity multiplier for debris
            debrisGravity: 9.8,       // Gravity applied to debris
            debrisDrag: 0.2,          // Air resistance factor for debris
            debrisBounce: 0.4         // How much debris bounces off surfaces
        }
    } = options;
    
    // IMPORTANT: Store the absolute world position for debris calculations
    const worldPosition = position.clone();
    
    // Create the group to hold main explosion elements (NOT debris)
    const explosionGroup = new THREE.Group();
    explosionGroup.position.copy(position);
    scene.add(explosionGroup);
    
    // 1. Create hemispheric blast
    const hemisphereGeometry = new THREE.SphereGeometry(0.1, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2);
    // Use provided hemisphereColor or fall back to regular color
    const blastColor = hemisphereColor || color;
    const hemisphereMaterial = createExplosionMaterial(blastColor, 2.0);
    const hemisphere = new THREE.Mesh(hemisphereGeometry, hemisphereMaterial);
    hemisphere.position.y = 0.05;
    explosionGroup.add(hemisphere);
    
    // 2. Create particle system for the main explosion
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const offsets = new Float32Array(count);
    
    // Generate random particle positions and velocities
    for (let i = 0; i < count; i++) {
        // Random position near center with greater spread
        const radius = Math.random() * 0.2 * scale;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        
        positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
        positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
        positions[i * 3 + 2] = radius * Math.cos(phi);
        
        // Random velocity with stronger outward direction
        const dirX = positions[i * 3];
        const dirY = positions[i * 3 + 1];
        const dirZ = positions[i * 3 + 2];
        const dirLength = Math.sqrt(dirX*dirX + dirY*dirY + dirZ*dirZ) || 1.0;
        
        // Normalize and apply speed
        const speed = 1.0 + Math.random() * 2.0;
        velocities[i * 3] = (dirX / dirLength) * speed * scale * 1.5;
        velocities[i * 3 + 1] = ((dirY / dirLength) * 0.5 + 0.5) * speed * scale * 1.5;
        velocities[i * 3 + 2] = (dirZ / dirLength) * speed * scale * 1.5;
        
        // Add some randomness to velocities
        velocities[i * 3] += (Math.random() - 0.5) * speed * scale * 0.5;
        velocities[i * 3 + 1] += (Math.random() - 0.5) * speed * scale * 0.5;
        velocities[i * 3 + 2] += (Math.random() - 0.5) * speed * scale * 0.5;
        
        // Random size
        sizes[i] = 0.3 + Math.random() * 0.7;
        
        // Random time offset for staggered animation
        offsets[i] = Math.random() * 0.3;
    }
    
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
    geometry.setAttribute('offset', new THREE.BufferAttribute(offsets, 1));
    
    // Create material and particles
    const material = createParticleSystemMaterial(color, size);
    const particles = new THREE.Points(geometry, material);
    explosionGroup.add(particles);
    
    // 3. Create debris particles if requested - Using predetermined paths
    let debrisMeshes = [];
    if (includeDebris) {
        const debrisMaterial = createDebrisParticlesMaterial(color);
        
        // Create random debris geometries
        const debrisGeometries = [
            new THREE.BoxGeometry(0.5, 0.3, 0.15),
            new THREE.ConeGeometry(0.4, 0.4, 4),
            new THREE.TetrahedronGeometry(0.45)
        ];
        
        // Instead of using trajectories, create each debris with its own flight path
        for (let i = 0; i < debrisCount; i++) {
            // Select a random geometry
            const geoIndex = Math.floor(Math.random() * debrisGeometries.length);
            const debris = new THREE.Mesh(
                debrisGeometries[geoIndex].clone(),
                debrisMaterial.clone()
            );
            
            // CRITICAL: Add debris directly to scene at absolute world position
            // This matches how the grenade debris works
            debris.position.copy(worldPosition);
            scene.add(debris);
            
            // Create direct outward velocity from center - more like the grenade implementation
            const angle = Math.random() * Math.PI * 2;
            const upTilt = Math.random() * Math.PI * 0.5; // 0 to 90 degrees upward
            
            // Apply physics-based velocity with configurable min/max range
            const velocityMultiplier = physics.debrisVelocityMin + 
                Math.random() * (physics.debrisVelocityMax - physics.debrisVelocityMin);
            
            const speed = velocityMultiplier * scale;
            
            // Calculate velocity components with strong outward direction 
            const velocity = new THREE.Vector3(
                Math.cos(angle) * Math.cos(upTilt) * speed,
                Math.sin(upTilt) * speed + 1.5, // Add upward boost for better arcs
                Math.sin(angle) * Math.cos(upTilt) * speed
            );
            
            // Add some randomization to rotation
            const rotationAxis = new THREE.Vector3(
                Math.random() - 0.5,
                Math.random() - 0.5, 
                Math.random() - 0.5
            ).normalize();
            
            // Store physics properties in userData for animation
            debris.userData = {
                velocity: velocity,
                rotationAxis: rotationAxis,
                rotationSpeed: Math.random() * 5 + 3, // Fast rotation
                gravity: physics.debrisGravity * scale, // Configurable gravity
                drag: physics.debrisDrag, // Air resistance factor
                bounce: physics.debrisBounce, // Bounce factor for collisions
                lifetime: duration,
                age: 0,
                hasHitGround: false // Track if debris has hit the ground
            };
            
            debrisMeshes.push(debris);
        }
    }
    
    // Time tracking for animation
    let elapsed = 0;
    
    // Add a method for forced cleanup
    const forceCleanup = () => {
        try {
            // Immediately remove from scene and dispose geometries/materials
            if (explosionGroup && explosionGroup.parent) {
                scene.remove(explosionGroup);
            }
            
            // Clean up hemisphere
            if (hemisphere && hemisphere.geometry) {
                hemisphere.geometry.dispose();
            }
            if (hemisphereMaterial) {
                hemisphereMaterial.dispose();
            }
            
            // Clean up particles
            if (geometry) {
                geometry.dispose();
            }
            if (material) {
                material.dispose();
            }
            
            // Clean up all debris meshes
            for (const debris of debrisMeshes) {
                try {
                    if (debris && debris.parent) {
                        scene.remove(debris);
                    }
                    if (debris && debris.geometry) {
                        debris.geometry.dispose();
                    }
                    if (debris && debris.material) {
                        debris.material.dispose();
                    }
                } catch (error) {
                    console.warn('Error cleaning up debris:', error.message);
                }
            }
            debrisMeshes = [];
            
            // Signal that the explosion is done
            return false;
        } catch (error) {
            console.warn('Error during explosion cleanup:', error.message);
            return false;
        }
    };
    
    // Return an object with an update method and cleanup methods
    return {
        position: worldPosition.clone(), // Store position for distance checks
        update: (dt) => {
            // Add a try-catch to the entire update method
            try {
                elapsed += dt;
                
                // Check if animation should end
                if (elapsed > duration * 1.2) {
                    return forceCleanup();
                }
                
                // Update hemisphere scale with safety checks
                if (hemisphere && hemisphere.parent) {
                    const scale = Math.min(6, 1 + elapsed * 5);
                    hemisphere.scale.set(scale, scale * 0.6, scale);
                    
                    // Add safety check for hemisphere material
                    if (hemisphereMaterial && hemisphereMaterial.uniforms && 
                        typeof hemisphereMaterial.uniforms.time !== 'undefined') {
                        try {
                            hemisphereMaterial.uniforms.time.value = elapsed;
                        } catch (error) {
                            console.warn('Error updating hemisphere material:', error.message);
                        }
                    }
                }
                
                // Update particle system with safety checks
                if (material && material.uniforms && typeof material.uniforms.time !== 'undefined') {
                    try {
                        material.uniforms.time.value = elapsed;
                    } catch (error) {
                        console.warn('Error updating particle material:', error.message);
                    }
                }
                
                // Update debris particles with physics
                for (let i = debrisMeshes.length - 1; i >= 0; i--) {
                    const debris = debrisMeshes[i];
                    
                    // Skip if debris has been removed or disposed
                    if (!debris || !debris.parent) {
                        debrisMeshes.splice(i, 1);
                        continue;
                    }
                    
                    // Handle undefined userData as a safeguard
                    if (!debris.userData) {
                        scene.remove(debris);
                        debrisMeshes.splice(i, 1);
                        continue;
                    }
                    
                    try {
                        debris.userData.age += dt;
                        
                        // Scale down debris over time
                        const lifeProgress = debris.userData.age / debris.userData.lifetime;
                        // Only apply scaling if the debris still has a valid scale attribute
                        if (debris.scale) {
                            const scaleValue = 1.0 - lifeProgress * 0.7;
                            debris.scale.set(scaleValue, scaleValue, scaleValue);
                        }
                        
                        // Remove debris after lifetime
                        if (lifeProgress >= 1.0) {
                            scene.remove(debris);
                            debrisMeshes.splice(i, 1);
                            continue;
                        }
                        
                        // Apply physics (if valid properties exist)
                        if (debris.userData.velocity) {
                            // Apply gravity to vertical velocity
                            debris.userData.velocity.y -= debris.userData.gravity * dt;
                            
                            // Apply drag to slow down velocity over time
                            debris.userData.velocity.multiplyScalar(1.0 - debris.userData.drag * dt);
                            
                            // Update position based on velocity
                            debris.position.add(debris.userData.velocity.clone().multiplyScalar(dt));
                            
                            // Floor collision
                            if (debris.position.y < 0.1 && !debris.userData.hasHitGround) {
                                debris.position.y = 0.1;
                                debris.userData.velocity.y = -debris.userData.velocity.y * debris.userData.bounce;
                                debris.userData.velocity.x *= 0.8;
                                debris.userData.velocity.z *= 0.8;
                                debris.userData.hasHitGround = true;
                            }
                        }
                        
                        // Rotate debris if rotation properties exist
                        if (debris.userData.rotationAxis && debris.rotation) {
                            debris.rotateOnAxis(
                                debris.userData.rotationAxis, 
                                debris.userData.rotationSpeed * dt
                            );
                        }
                        
                        // Fade out debris
                        if (debris.material && debris.material.opacity !== undefined) {
                            // Apply fade out in last 20% of lifetime
                            if (lifeProgress > 0.8) {
                                debris.material.opacity = (1.0 - lifeProgress) * 5; // Map 0.8-1.0 to 1.0-0.0
                            }
                        }
                    } catch (error) {
                        console.warn('Error updating debris:', error.message);
                        // Remove problematic debris
                        scene.remove(debris);
                        debrisMeshes.splice(i, 1);
                    }
                }
                
                return true;
            } catch (error) {
                console.warn('Fatal error in explosion update:', error.message);
                return forceCleanup();
            }
        },
        forceCleanup: forceCleanup,
        cleanup: forceCleanup  // Alias for compatibility
    };
};

// New shader material for debris particles
export const createDebrisParticlesMaterial = (color = 0xff5500) => {
    // Create a more vibrant version of the color
    const enhancedColor = new THREE.Color(color);
    // Brighten the color slightly for better visual effect 
    enhancedColor.r = Math.min(1.0, enhancedColor.r * 1.2);
    enhancedColor.g = Math.min(1.0, enhancedColor.g * 1.2);
    enhancedColor.b = Math.min(1.0, enhancedColor.b * 1.2);
    
    return new THREE.MeshStandardMaterial({
        color: enhancedColor,
        emissive: color,
        emissiveIntensity: 0.7, // Increased from 0.5 for better visibility
        roughness: 0.6, // Reduced from 0.7 for more shine
        metalness: 0.4, // Increased from 0.3 for more reflectivity
        flatShading: true,
        transparent: true,
        opacity: 1.0
    });
}; 