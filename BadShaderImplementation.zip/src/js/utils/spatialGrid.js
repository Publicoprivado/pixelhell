// SpatialGrid.js - A grid-based spatial partitioning system for faster collision detection
import { GAME } from './constants.js';

export class SpatialGrid {
    constructor(width, height, cellSize) {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;
        this.cols = Math.ceil(width / cellSize);
        this.rows = Math.ceil(height / cellSize);
        
        // Create the grid - a 2D array of cells, each containing entities
        this.grid = new Array(this.cols);
        for (let i = 0; i < this.cols; i++) {
            this.grid[i] = new Array(this.rows);
            for (let j = 0; j < this.rows; j++) {
                this.grid[i][j] = new Set(); // Using a Set for O(1) insertion/deletion
            }
        }
    }
    
    // Convert world coordinates to grid cell coordinates
    worldToGrid(x, z) {
        // Adjust for arena center at 0,0
        const adjustedX = x + this.width / 2;
        const adjustedZ = z + this.height / 2;
        
        const col = Math.floor(adjustedX / this.cellSize);
        const row = Math.floor(adjustedZ / this.cellSize);
        
        // Clamp to grid bounds
        return {
            col: Math.max(0, Math.min(this.cols - 1, col)),
            row: Math.max(0, Math.min(this.rows - 1, row))
        };
    }
    
    // Add an entity to the grid
    insert(entity) {
        const pos = entity.getPosition();
        const { col, row } = this.worldToGrid(pos.x, pos.z);
        
        // Add entity to the cell
        this.grid[col][row].add(entity);
        
        // Store grid position on entity for quick removal later
        entity.gridPosition = { col, row };
    }
    
    // Update an entity's position in the grid
    update(entity) {
        // Remove from old position
        this.remove(entity);
        
        // Add to new position
        this.insert(entity);
    }
    
    // Remove an entity from the grid
    remove(entity) {
        if (entity.gridPosition) {
            const { col, row } = entity.gridPosition;
            this.grid[col][row].delete(entity);
            entity.gridPosition = null;
        }
    }
    
    // Get all entities in nearby cells (including diagonal)
    getNearbyEntities(entity) {
        const pos = entity.getPosition();
        const { col, row } = this.worldToGrid(pos.x, pos.z);
        const result = new Set();
        
        // Check the entity's cell and all adjacent cells
        for (let i = Math.max(0, col - 1); i <= Math.min(this.cols - 1, col + 1); i++) {
            for (let j = Math.max(0, row - 1); j <= Math.min(this.rows - 1, row + 1); j++) {
                for (const nearby of this.grid[i][j]) {
                    if (nearby !== entity) {
                        result.add(nearby);
                    }
                }
            }
        }
        
        return Array.from(result);
    }
    
    // Get all entities in the cell containing the specified position
    getEntitiesAt(x, z) {
        const { col, row } = this.worldToGrid(x, z);
        return Array.from(this.grid[col][row]);
    }
    
    // Get all entities from all cells in the grid
    getEntities() {
        const entities = [];
        for (let i = 0; i < this.cols; i++) {
            for (let j = 0; j < this.rows; j++) {
                for (const entity of this.grid[i][j]) {
                    entities.push(entity);
                }
            }
        }
        return entities;
    }
    
    // Clear the entire grid
    clear() {
        for (let i = 0; i < this.cols; i++) {
            for (let j = 0; j < this.rows; j++) {
                this.grid[i][j].clear();
            }
        }
    }
} 